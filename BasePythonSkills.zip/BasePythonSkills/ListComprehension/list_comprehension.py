# List comprehension
# Создаем пустой список letter_list
# Добавляем в список буквы при помощи .append

# greeting = 'Hello'
# letter_list = []
# for letter in greeting: # Для каждой буквы из строки greeting сделать следующее
#     letter_list.append(letter) # Добавить букву в наш список letter_list
# print(letter_list)

# Способ 2
# letter_list = [letter for letter in greeting] # Для каждой буквы из строки greeting, поместить букву в список letter_list
# print(letter_list)
#
# number_list = [number for number in '0123456789']
# print(number_list)
#
# number_list_1 = [num for num in range(0,10)]
# print(number_list_1)
#
# number_list_2 = [num ** 2 for num in range(0,10)] # Возводим каждый элемент из range в квадрат и вставляем его в список
# print(number_list_2)
#
# number_list_3 = [- ((num - 3)/2) ** 2 for num in range(0,10)]
# print(number_list_3)

# number_list = [6, 43, -2, 11, -55, -12, 3, 345]
# new_list = [number for number in number_list if number > 0]
# print(new_list)
#
# new_list_1 = ['+' if number > 0 else '-' for number in number_list]
# # Распечатать + если число больше 0, иначе - для чисел в number_list
# print(new_list_1)



# Hometask_1
# Without list comprehension

# new_greeting_list = []
# greeting = ['Hello', 'hi', 'hey', 'hola']
# for letter in greeting:
#     # let = str(letter)
#     new_greeting_list.append(letter[1])
# print(new_greeting_list)
#
# # With list comprehension
# new_greeting_list_1 = [(str(l))[1] for l in greeting]
# print(new_greeting_list_1)
#
#
# # Hometask_2
# # Without list comprehension
#
# digits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
# new_digits = []
# for num in digits:
#     if num % 2 == 1:
#         new_digits.append(num)
# print(new_digits)
#
# # With list comprehension
#
# new_digits_1 = [num for num in digits if num % 2 == 1 ]
# print(new_digits_1)


# # Dictionary comprehension
# number_dict = {'first': 1, 'second': 2, 'third': 3}
# # Необходимо создать пару переменных key, value
# # Для key, value из number_dict мы получаем value **3 в новый dictionary. .items выводит пару key-value
# new_dict = {key: value ** 3 for key, value in number_dict.items()}
# print(new_dict)
#
# Есть возможность получать значение не только из словаря, но и из списка
# number_list = [6, 43, 0, -2, 11, -55, -12, 3, 345]
# # number_dict_1 = {number: number ** 2 for number in number_list}
# # print(number_dict_1)
# #
# # # В такой форме записи допускается использовать несколько else
# number_dict_2 = {number: 'positive' if number > 0 else 'negative' if number < 0
# else 'zero' for number in number_list}
# print(number_dict_2)


# Set Comprehension
number_list = [6, 43, 0, -2, 11, -55, -12, 3, 345]
number_set = {number ** 2 for number in number_list}
print(number_set)

number_set_1 = {number ** 2 for number in range(3, 11)}
print(number_set_1)

letter_set = {letter.upper() for letter in 'Hello'}
print(letter_set)