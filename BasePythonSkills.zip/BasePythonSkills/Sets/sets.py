rainbow_colors = {'red', 'orange', 'yellow', 'green', 'blue',
                  'indigo', 'violet'}
print(rainbow_colors)
print(type(rainbow_colors))

# Создание пустого множества
empty_set = {}
print(type(empty_set))
empty_set = set()
print(type(empty_set))

number_list = [1, 43, 56]
text_tuple = ('asd', 'wevwd', 'edwe')
set_from_list = set(number_list)
set_from_tuple = set(text_tuple)
print(set_from_list, set_from_tuple)

# Adding new element
set_from_list.add(789)
set_from_tuple.add('qwqw')
set_from_list.add(789)
set_from_tuple.add('qwqw')
print(set_from_list, set_from_tuple) # Повторяющиеся объекты не добавляются

# deleting an element

# Удаление случайного элемента
set_from_list.pop()

# Удаление определенного элемента
set_from_list.remove(43)
print(set_from_list)

# Еще один метод
set_from_list.discard(43)

# Чистка всего множества
set_from_list.clear()
print(set_from_list)


# Hometask

fruit_basket = ('apple', 'pineapple', 'orange', 'pineapple', 'apple' 'watermelon',
                'peach', 'orange', 'apple', 'pineapple', 'orange', 'strawberry')
set_fruit_basket = set(fruit_basket)
print(type(set_fruit_basket))
print(set_fruit_basket)
