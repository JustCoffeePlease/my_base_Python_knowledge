# Основной файл, отвечает за запуск самого бота
# Импорт из библиотеки aiogram executor в котором лежит start_polling. Он отвечает за запуск бота
from aiogram import executor

# Из второго файла в корневой директоии импортируем диспетчер (Доставщик обновлений, сообщений к обработчикам сообщений)
# в самом дистпетчере прописывается работа с обновлениями, пришедших от пользователей к боту
from loader import dp

# Импорт папок из корневой директории. Они должны импортироваться именно в таком порядке, для их корректной работы
import middlewares, filters, handlers

# Импортируем из вспомогательных функций функцию оповещения администратора о том, что бот запущен (on_startup_notify)
# и функцию установки дефолтных команд для бота (set_default_commands)
from utils.notify_admins import on_startup_notify
from utils.set_bot_commands import set_default_commands


async def on_startup(dispatcher):
    # Устанавливаем дефолтные команды
    await set_default_commands(dispatcher)

    # Уведомляет про запуск
    await on_startup_notify(dispatcher)


if __name__ == '__main__':
    executor.start_polling(dp, on_startup=on_startup)

