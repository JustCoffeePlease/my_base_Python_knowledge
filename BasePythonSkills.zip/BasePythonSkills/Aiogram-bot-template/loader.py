# В этот файл подгружаются наши переменные.
# Здесь создаются следующие глобальные переменные: bot, storage, dp

from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from data import config

# Объект bot отвечает за отправку запросов телеграму с помощью бота
bot = Bot(token=config.BOT_TOKEN, parse_mode=types.ParseMode.HTML)

# Объект storage отвечает за хранилище наших состояний
storage = MemoryStorage()

# Объект dp это доставщик и обработчик всех updates по всей цепочке.
dp = Dispatcher(bot, storage=storage)

# Если будет глобальная переменная для работы с БД, ее следует размещать в этом файле
# и потом импортировать куда-то в подпапки