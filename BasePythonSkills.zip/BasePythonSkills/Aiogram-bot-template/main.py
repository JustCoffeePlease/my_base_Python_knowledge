# This is a sample Python script.
import requests
from bs4 import BeautifulSoup
import re
# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.

def get_page():
    response = requests.get('https://whattomine.com/miners?cost=0.00')
    return response.text

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    #Th, Gb, T.....
    regex = r"([0-9]+[T,M,G]$)|([0-9]+[T,M,GB]\D$)|(\d\d\.[0-9]+[T,M,G]$)|(-[0-9]+[T,M,G]$)"

    whats_to_mine_page = get_page()
    soup = BeautifulSoup(whats_to_mine_page, 'lxml')
    rows = soup.find_all('tr')
    for row in rows[1:]:
        # print(row)
        matches = re.finditer(regex, row.find_all('td')[0].find('a').contents[0], re.MULTILINE)
        for match in matches:
            print(match.group())
        print(row.find_all('td')[0].find('a').contents[0], row.find_all('td')[2].contents[0] , row.find_all('td')[3].contents[0], row.find_all('td')[4].contents[0], row.find_all('td')[5].contents[0])