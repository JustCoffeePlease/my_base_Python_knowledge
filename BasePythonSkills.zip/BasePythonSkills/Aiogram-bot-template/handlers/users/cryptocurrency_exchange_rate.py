import logging

from aiogram.dispatcher.filters import Command
from aiogram.types import Message, CallbackQuery

from keyboards.inline.callback_datas import check_callback
from keyboards.inline.choice_crypto import choose_currency, bitcoin_notification, etherium_notification
from loader import dp


@dp.message_handler(Command('cryptoex'))
async def show_cryptoex(message: Message):
    await message.answer(text='Выберите криптовалюту, которая вас интересует \n'
                              'Для возврата нажмите кнопку "Отмена"', reply_markup=choose_currency)


# декоратор для того, чтобы ловить нажатие на кнопку 'Bitcoin'
@dp.callback_query_handler(text_contains='bitcoin')
async def choosing_bitcoin(call: CallbackQuery):
    await call.answer(cache_time=60)
    callback_data = call.data
    logging.info(f'call = {callback_data}')
    await call.message.answer('Курс Bitcoin на текущий момент:__', reply_markup=bitcoin_notification)


@dp.callback_query_handler(check_callback.filter(crypto_name='etherium'))
async def choosing_etherium(call: CallbackQuery, callback_data: dict):
    await call.answer(cache_time=60)
    logging.info(f'call = {callback_data}')
    await call.message.answer('Курс Etherium на текущий момент:__', reply_markup=etherium_notification)


# Обработчик кнопки "отмена"
@dp.callback_query_handler(text='cancel')
async def cancel_inline_button(call: CallbackQuery):
    await call.answer('Вы нажали кнопку "Отмена"', show_alert=True)
    await call.message.edit_reply_markup(reply_markup=None)
