from keyboards.inline.choice_crypto import choose_currency
from loader import dp
from aiogram.types import Message, ReplyKeyboardRemove
from keyboards.default import menu
from aiogram.dispatcher.filters import Command, Text


@dp.message_handler(Command('menu'))
async def show_menu(message: Message):
    await message.answer("Какое действие вы бы хотели выполнить?", reply_markup=menu)


# @dp.message_handler(Text(equals=['Подобрать оборудование', 'Курс криптовалют на каждый день', 'Написать админу']))
# async def get_command(message: Message):
#     await message.answer(f'Вы выбрали {message.text}', reply_markup=ReplyKeyboardRemove())


@dp.message_handler(Text(equals=['Курс криптовалют на каждый день']))
async def get_command(message: Message):
    await message.answer(text='Выберите криптовалюту, которая вас интересует \n'
                              'Для возврата нажмите кнопку "Отмена"', reply_markup=choose_currency)