from aiogram.utils.callback_data import CallbackData

check_callback = CallbackData('check', 'crypto_name')