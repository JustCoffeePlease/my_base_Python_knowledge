from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from keyboards.inline.callback_datas import check_callback

choose_currency = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="Bitcoin", callback_data=check_callback.new(crypto_name='bitcoin'))],
    [InlineKeyboardButton(text='Etherium', callback_data=check_callback.new(crypto_name='etherium'))],
    [InlineKeyboardButton(text='Tronix', callback_data=check_callback.new(crypto_name='tronix'))],
    [InlineKeyboardButton(text='Tether', callback_data=check_callback.new(crypto_name='tether'))],
    [InlineKeyboardButton(text='Decentraland', callback_data=check_callback.new(crypto_name='Decentraland'))],
    [InlineKeyboardButton(text='Отмена', callback_data='cancel')]])


bitcoin_notification = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Уведомления подключены')]])
etherium_notification = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Уведомления подключены')]])