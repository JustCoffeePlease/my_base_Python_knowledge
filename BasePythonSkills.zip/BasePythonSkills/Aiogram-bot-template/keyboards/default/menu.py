# Импортируем из библиотеки aiogram типы клавиатур
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

# Создаем объект клавиатуры
menu = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text='Подобрать оборудование')],
                                     [KeyboardButton(text='Курс криптовалют на каждый день')],
                                     [KeyboardButton(text='Написать админу')]], resize_keyboard=True)
