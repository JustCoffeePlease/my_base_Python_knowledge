# list = список

number_list = [32, 12, 65.56]
print(number_list)

some_list = [12, 32.5, 'Olesia']
print(some_list)
print(len(some_list))

# indexing and slicing
print(some_list[1])
another_list = some_list[:2]
print(another_list)

# В строках мы не можем менять элементы строк, а в списках это возможно
some_list[1] = 'Hello'
print(some_list)

new_list = some_list + another_list
print(new_list)

# adding items

# new_list[5] = 'new item'
# print(new_list)
new_list.append('new item')
print(new_list)
new_list.insert(0,'start')
print(new_list)

# removing items
# Удаление по индексу
# new_list.pop()
# print(new_list)
# new_list.pop(0)
# print(new_list)
# deleted_item = new_list.pop()
deleted_item = new_list.pop(-3)
print(deleted_item)
# Удаление по значению
deleted_item = new_list.remove(12)
print(new_list)
print(deleted_item)

# Sort
new_number_list = [-5, 55, 36, 89, 4]
letter_list = ['a', 'b', 'c', 'd', 'e']

new_number_list.sort()
letter_list.sort()

print(new_number_list)
print(letter_list)

# Revers

new_number_list.reverse()
letter_list.reverse()
print(new_number_list)
print(letter_list)

# Добавление списка в список
letter_list.append(new_number_list)
print(letter_list)

# Hometask

hometask_list = [-1, 1, 23.5, 'D', 'Cola', 999]
new_hometask_list = hometask_list[0:4]
print(new_hometask_list)
new_hometask_list.pop(0)
print(new_hometask_list)