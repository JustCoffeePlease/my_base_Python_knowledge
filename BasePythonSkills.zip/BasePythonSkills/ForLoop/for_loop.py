# number_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# for num in number_list:
#     # print(num)
#     #   print(str(num) + ' Hola')
#     if num % 2 == 0:
#         print(num)
#     else:
#         print('Hey')

# numbers_sum = 0
# for num in number_list:
#     numbers_sum = numbers_sum + num
#     #print(numbers_sum) # Вывод результата на каждом шаге
# print(numbers_sum)

# greeting = 'Hello Python'
# for let in 'Hello Python':
#     if let != 'o':
#         print(let)

# for let in 'Hello Python':
#     print('One more letter')

# tuple_list = [('a', 'b'), ('c', 'd'), ('e', 'f')]
# for item in tuple_list:
#     print(item)
# for let_1, let_2 in tuple_list:
#     print(let_1, let_2)
#
# for let_1, let_2 in tuple_list:
#     print(let_1)
#     print(let_2)

# tuple_list_1 = [('a', 'b', 1), ('c', 'd', 4), ('e', 'f', 5)]
# for let_1, let_2, num in tuple_list_1:
#     print(let_1, let_2, num)


dictionary = {'key_1':'value_1', 'key_2':'value_2', 'key_3':'value_4' }

# key-value pairs in dictionary
for item in dictionary.items():
    print(item)

# keys
for item in dictionary:
    print(item)
for item in dictionary.keys():
    print(item)
for key, value in dictionary.items():
    print(key)

# values
for item in dictionary.values():
    print(item)
for key, value in dictionary.items():
    print(value)

# range - функция возвращает последовательность из чисел от 0 до параметра функции
# for _ in range(5): # Если переменная не используется, допускается ставить _
#     print('Hello')

# Hometask_1
# even_sum = 0
# range(10, 30)
# for x in range(10, 31):
#     if x % 2 == 0:
#         even_sum = even_sum + x
# print(even_sum)
#
# # Hometask_2
# greeting = input('Enter the any number: ')
# for _ in range(int(greeting)):
#     print('Hello')