# pack() - менеджер разметки

# 1. Put a widget inside a container and have it fill the container
# 2. Put number of widget in the column
# 3. Put a number of widgets in a row

from tkinter import *

main_window = Tk()

# По умолчанию, окно появляется в плотную в верхней левой части экрана.
# Мы можем задать смещение этого окна на +100 по OY и на 120 по OX
# main_window.geometry('800x600+100+120')

# my_label = Label(main_window, text='My text', bg='red')
# fill=X заполняет всю ширину. Если заполняем Y, то нужно указать дополнительно expand и присвоить численное значение
# Если хотим заполнить всю площадь, то fill = BOTH и expand=1
# my_label.pack(fill=X)
# my_label.pack(fill=Y, expand=1)
# my_label.pack(fill=BOTH, expand=1)

# red_label = Label(main_window, text='RED', bg='red', fg='white')
# red_label.pack(fill=BOTH, expand=1)
# green_label = Label(main_window, text='GREEN', bg='green', fg='white')
# green_label.pack(fill=BOTH, expand=1)
# blue_label = Label(main_window, text='BLUE', bg='blue', fg='white')
# blue_label.pack(fill=BOTH, expand=1)

# listbox = Listbox(main_window)
# listbox.pack(fill=BOTH, expand=1)
#
# for i in range(20):
#     listbox.insert(END, str(i))
# # Output:
# # Получаем listbox со списком от 0 до 19 внутри

# Укажем отступы
# red_label = Label(main_window, text='RED', bg='red', fg='white')
# red_label.pack(fill=BOTH, expand=1, padx=10)
# green_label = Label(main_window, text='GREEN', bg='green', fg='white')
# green_label.pack(fill=BOTH, expand=1, pady=10)
# blue_label = Label(main_window, text='BLUE', bg='blue', fg='white')
# blue_label.pack(fill=BOTH, expand=1, padx=10, pady=10)

# Закомментируем main_window.geometry('800x600+100+120') и уберем все атрибуты из pack()
# Выставим внутренние отступы
# red_label = Label(main_window, text='RED', bg='red', fg='white')
# red_label.pack(ipadx=50)
# green_label = Label(main_window, text='GREEN', bg='green', fg='white')
# green_label.pack(ipady=50)
# blue_label = Label(main_window, text='BLUE', bg='blue', fg='white')
# blue_label.pack()

# Получим упорядоченные элементы слева направо. Если хотим изменить на справа налево, надо изменить атрибут side=RIGHT
red_label = Label(main_window, text='RED', bg='red', fg='white')
red_label.pack(ipadx=50, side=LEFT)
green_label = Label(main_window, text='GREEN', bg='green', fg='white')
green_label.pack(ipady=50, side=LEFT)
blue_label = Label(main_window, text='BLUE', bg='blue', fg='white')
blue_label.pack(side=LEFT)

main_window.mainloop()
