from tkinter import *
from tkinter import ttk


def calculate(*args):
    try:
        value = float(celsius.get())
        fahrenheit.set(value * 33.8)
    except ValueError:
        pass


root = Tk()
root.title('Temperature converter')
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)
root.rowconfigure(1, weight=1)

celsius = StringVar()
fahrenheit = StringVar(value='Temperature in fahrenheit')

mainframe = ttk.Frame(root)
mainframe['padding'] = (10, 5)
mainframe['relief'] = 'sunken'
mainframe.columnconfigure(0, weight=1)
mainframe.columnconfigure(1, weight=5)
mainframe.rowconfigure(0, weight=1)
mainframe.rowconfigure(1, weight=1)
mainframe.grid(sticky='NSEW')

celsius_label = ttk.Label(mainframe, text='Celsium: ')
celsius_label.grid(row=0, column=0, padx=0, pady=10, sticky='W')

celsius_entry = ttk.Entry(mainframe, textvariable=celsius)
celsius_entry.grid(row=0, column=1, padx=(0, 5), sticky='EW')
celsius_entry.focus()

fahrenheit_label = ttk.Label(mainframe, text='Fahrenheit: ')
fahrenheit_label.grid(row=1, column=0, padx=0, pady=10, sticky='W')

fahrenheit_result = ttk.Label(mainframe, textvariable=fahrenheit)
fahrenheit_result.grid(row=1, column=1, sticky='EW', padx=0, pady=10)

buttons_frame = ttk.Frame(root, padding=(5, 5))
buttons_frame.grid(row=1, column=0, sticky='NSEW')
buttons_frame.columnconfigure(0, weight=2)
buttons_frame.columnconfigure(1, weight=2)

calculate_button = ttk.Button(buttons_frame, text='Calculate', command=calculate)
calculate_button.grid(row=0, column=0, padx=(0, 15), sticky='EW')

cancel_button = ttk.Button(buttons_frame, text='Cancel', command=root.destroy)
cancel_button.grid(row=0, column=1, sticky='EW')

root.bind("<Return>", calculate)

root.mainloop()

