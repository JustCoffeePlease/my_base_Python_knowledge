from tkinter import *
from tkinter import ttk
# ttk импортируется отдельно, потому что в нем используются новые виджеты

# Определяем функцию с произвольным количеством входных параметров,
# которая запускается каждый раз, когда user нажимает на calculate или Enter
# Функция получает значение value из Entry методом get
# Каждый раз, когда user меняет текст feet_entry, это значение сразу помещается в feet, которое извлекается
# в calculate. После вычисления значения meters, это значение помещается в виджет ttk.Label

def calculate(*args):
    try:
        value = float(feet.get())
        meters.set(int(0.3048 * value * 10000.0 + 0.5)/10000.0)
    except ValueError:
        pass

# Определяем основной виджет root
root = Tk()
# Присваиваем заголовок
root.title("Feet to Meters")

# создаем переменную mainframe и определяем ее как функцию модуля ttl .Frame().
# Внутрь помещаем принадлежность к виджету root и назначаем отступы padding
# Таким образом, mainframe это фрейм виджет, который содержит весь контент интерфейса, который помещен в root
mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))

# При помощи этих строк кода мы привязываемся к главному окну root таким образом что, если главное окно будет изменено,
# то mainframe должен расширится на всю площадь соответственно
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

# Далее создаются три главных виджета:
# feet_entry(поле, в которое user вводит feet),
# ttk.Label(поле, в которое помещается результат в метрах),
# ttk.Button(Кнопка, при помощи которой происходит вычисления

feet = StringVar()
# Создание виджета Entry
feet_entry = ttk.Entry(mainframe, width=7, textvariable=feet)
# Создание расположения виджета Entry при помощи метода grid
feet_entry.grid(column=2, row=1, sticky=(W, E))

# переменным feet и meters мы присваиваем StringVar(). В итоге, при помощи этих двух объектов устанавливаются слушатели
# изменения виджетов и переменных feet_entry и ttk.Label().

meters = StringVar()
# Создание виджета Label
# Создание расположения виджета Label при помощи метода grid
ttk.Label(mainframe, textvariable=meters).grid(column=2, row=2, sticky=(W, E))

# Параметр sticky= это "прилипание" к какой-то части. Здесь указываются стороны света N, S, E, W

# Создание виджета Button
# Создание расположения виджета Button при помощи метода grid
ttk.Button(mainframe, text="Calculate", command=calculate).grid(column=3, row=3, sticky=W)

ttk.Label(mainframe, text="feet").grid(column=3, row=1, sticky=W)
ttk.Label(mainframe, text="is equivalent to").grid(column=1, row=2, sticky=E)
ttk.Label(mainframe, text="meters").grid(column=3, row=2, sticky=W)

# Далее в цикле, для каждого виджета в mainframe, устанавливаются padx и pady, которые образуют зазоры между виджетов
for child in mainframe.winfo_children():
    child.grid_configure(padx=5, pady=5)

# При запуске окна, курсор автоматиччески фокусируется в поле Entry
feet_entry.focus()

# Создание связи функции calculate с кнопкой <Return> (или Enter на клавиатуре)
root.bind("<Return>", calculate)

# Производится запуск окна и отрисовка
root.mainloop()


#############################################################################################

# from tkinter import *
# from tkinter import ttk
#
# root = Tk()
#
# l =ttk.Label(root, text="Starting...")
# l.grid()
# l.bind('<Enter>', lambda e: l.configure(text='Moved mouse inside'))
# l.bind('<Leave>', lambda e: l.configure(text='Moved mouse outside'))
# l.bind('<ButtonPress-1>', lambda e: l.configure(text='Clicked left mouse button'))
# l.bind('<3>', lambda e: l.configure(text='Clicked right mouse button'))
# l.bind('<Double-1>', lambda e: l.configure(text='Double clicked'))
# l.bind('<B3-Motion>', lambda e: l.configure(text='right button drag to %d,%d' % (e.x, e.y)))
# root.mainloop()

############################################################################################
# # Basic Widgets, frames
# from tkinter import *
# from tkinter import ttk
#
# # Виджет frame - рамка, используется для размещения других виджетов
# # Создание рамки
# root = Tk()
# frame = ttk.Frame(root, width=300, height=300)
#
# # Так же мы можем устанавливать дополнительное пространство внутри виджета, чтобы было какое-то расстояние между
# # виджетом и самой рамкой
# # Создание расстояния между виджетом и рамкой (зазор). Указывая один параметр в padding, получим одинаковый зазор
# # вокруг все рамки. Указывая два числа, получим разные зазоры по вертикали и горизонтали.
# # Указывая 4 числа, получим разные зазоры со всех сторон
# frame['padding'] = (5, 10, 15, 20)
#
# # Так же можно установить толщину рамки и ее отображение
# frame['borderwidth'] = 5
# frame['relief'] = 'raised'
#
# # Отображение рамки.
# # Для корректного отображения, надо передать конфигурационные опции, которые определяют, как будет
# # отображаться виджет. Эти параметры width= и height= должны быть отображены в ttk.Frame()
# frame.grid()
#
# # Виджет Label - виджет, размещающий в себе текст или изображение. Используется для идентификации контролеров
# # Создание виджета Label. Для создания необходимо передать родителя parent (окно, в котором будет размещаться виджет)
# # и дополнительный параметр, например text=
# label = ttk.Label(frame, text='Full name: ')
# label.grid()
#
# # Мы можем менять содержимое этого виджета
# resultsContents = StringVar()
# label['textvariable'] = resultsContents
# resultsContents.set('New value on display')
#
#
# root.mainloop()