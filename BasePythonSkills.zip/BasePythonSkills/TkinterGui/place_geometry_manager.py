from tkinter import *

# Put widgets at specific places
# Put one widget in another
root = Tk()

root.geometry('600x600+100+100')

# Для функции place() мы должны присвоить координаты, чтобы разместить наш виджет
# width - длина виджета, height -высота
# red_label = Label(root, text='RED', bg='red', fg='white')
# red_label.place(x=200, y=500, width=200)
# green_label = Label(root, text='GREEN', bg='green', fg='white')
# green_label.place(x=50, y=275, height=50)
# blue_label = Label(root, text='BLUE', bg='blue', fg='white')
# blue_label.place(x=250, y=250, width=100, height=100)

# Мы можем размещать виджеты относительно родительского элемента
# red_label_rel_height = Label(root, text='RED relheight=0.3', bg='red', fg='white')
# red_label_rel_height.place(relheight=0.3)
# green_label_rel_width = Label(root, text='GREEN relwidth=0.7', bg='green', fg='white')
# green_label_rel_width.place(relwidth=0.7)
# blue_label_rel_x  = Label(root, text='BLUE relx=0.2', bg='blue', fg='white')
# blue_label_rel_x.place(relx=0.2)
# black_label_rel_y  = Label(root, text='BLACK rely=0.4', bg='black', fg='white')
# black_label_rel_y.place(rely=0.4)

# Вложим один виджет в другой
label = Label(root, text='Some Text', bg='black', fg='white')
label.place(width=200, height=200, x=200, y=200)
button = Button(root, text='Enter')
button.place(in_=label, relx=0.5, rely=0.5, anchor=CENTER)

root.mainloop()