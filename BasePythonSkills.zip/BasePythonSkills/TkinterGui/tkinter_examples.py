from tkinter import *
from tkinter import font

# Создание основного окна, на котором будут располагаться все остальные виджеты
root_window = Tk()

# Установим размеры окна. Передаем строку с размерами в пикселях
root_window.geometry('500x500')

# Установим заголовок
root_window.title('Welcome screen')

# Создадим первый виджет, для этого используем Label(). Внутрь передаем окно, в котором будет располагаться виджет,
# далее передаем сам виджет, в нашем случае это текст? далее в font передадим шрифт текста, высоту и жирность/курсив,
# в fg передаем цвет текста, в bg передаем цвет фона, в relief помещаем вариант рамки
hello_label = Label(root_window, text='Welcome to tkinter',
                    font=('arial', 20, 'bold'), fg='blue', bg='red',
                    relief='solid') # solid, flat, raised, sunken, ridge, groove
version_label = Label(root_window, text='version 8.6')
go_button = Button(root_window, text='Enter',
                    font=('arial', 20, 'bold'), fg='blue', bg='red',
                    relief=RAISED)
# Размести вновь созданный виджет в окне по центру строки
hello_label.pack()

# Чтобы разместить вновь созданный виджет иначе, мы можем использовать .place()
# Внутри скобок передадим координаты верхней левой точки
version_label.place(x=222, y=45)

go_button.pack()
# Чтобы получить все возможные варианты шрифтов, надо импортировать font и воспользоваться .families()
# print(font.families())
# Узнаем версию Тkinter
print(TkVersion)
# Чтобы это окно работало, нам нужно записать функцию .mainloop()
# При помощи этой функции запускается графический интерфейс
root_window.mainloop()


