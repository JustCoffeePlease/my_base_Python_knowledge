# from tkinter import *
#
# # grid позволяет расположить виджеты как колонки и строки
#
# root_window = Tk()
#
# red_label = Label(root_window, text='RED', bg='red', fg='white', width=20, height=10)
# red_label.grid(row=0, column=0)
# green_label = Label(root_window, text='GREEN', bg='green', fg='white', width=20, height=10)
# green_label.grid(row=0, column=1)
# blue_label = Label(root_window, text='BLUE', bg='blue', fg='white', width=20, height=10)
# blue_label.grid(row=0, column=2)
#
# red_label_1 = Label(root_window, text='RED', bg='red', fg='white', width=20, height=10)
# red_label_1.grid(row=1, column=0)
# green_label_1 = Label(root_window, text='GREEN', bg='green', fg='white', width=20, height=10)
# green_label_1.grid(row=1, column=1)
# blue_label_1 = Label(root_window, text='BLUE', bg='blue', fg='white', width=20, height=10)
# blue_label_1.grid(row=1, column=2)
#
# button_1 = Button(root_window, text='button 1')
# button_1.grid(row=2, column=0)
# button_2 = Button(root_window, text='button 2')
# button_2.grid(row=2, column=1)
# button_3 = Button(root_window, text='button 3')
# button_3.grid(row=2, column=2)
#
# root_window.mainloop()

# from tkinter import *
# from tkinter import ttk
#
# root = Tk()
#
# # Создаем виджет Frame, который расположен в root
# content = ttk.Frame(root)
# # Создаем Frame, который расположен в content для него указаны размер зазора, тип рамки и размеры
# frame = ttk.Frame(content, borderwidth=5, relief='sunken', width=200, height=100)
# # Создаем виджет Label, который расположен в content
# name_label = ttk.Label(content, text='Name')
# # Создаем поле, в котором user будет что-то вводить
# name = ttk.Entry(content)
#
# # Далее создаем три переменные с параметром Boolean и в них помещается True, False, True
# onevar = BooleanVar()
# twovar = BooleanVar()
# threevar = BooleanVar()
#
# onevar.set(True)
# twovar.set(False)
# threevar.set(True)
#
# # Эти три переменные помещаются в Checkbutton. В этом виджете есть опция variable, и в зависимости от значения,
# # который будет присвоен этой опции, будет стоять отмеченный Checkbox или нет(В момент запуска кода)
# one = ttk.Checkbutton(content, text='One', variable=onevar, onvalue=True)
# two = ttk.Checkbutton(content, text='two', variable=twovar, onvalue=True)
# three = ttk.Checkbutton(content, text='Three', variable=threevar, onvalue=True)
# ok = ttk.Button(content, text='OK')
# cancel = ttk.Button(content, text='Cancel')
#
# content.grid(column=0, row=0)
# frame.grid(column=0, row=0, columnspan=3, rowspan=2)
# name_label.grid(column=3, row=0, columnspan=2, sticky=(E, S))
# name.grid(column=3, row=1, columnspan=2, sticky=(N, S, W, E))
# one.grid(column=0, row=3)
# two.grid(column=1, row=3)
# three.grid(column=2, row=3)
# ok.grid(column=3, row=3)
# cancel.grid(column=4, row=3)
#
#
# root.mainloop()

from tkinter import *
from tkinter import ttk

root = Tk()

content = ttk.Frame(root, padding=(3, 3, 12, 12))
frame = ttk.Frame(content, borderwidth=5, relief="ridge", width=200, height=100)
namelbl = ttk.Label(content, text="Name")
name = ttk.Entry(content)

onevar = BooleanVar()
twovar = BooleanVar()
threevar = BooleanVar()

onevar.set(True)
twovar.set(False)
threevar.set(True)

one = ttk.Checkbutton(content, text="One", variable=onevar, onvalue=True)
two = ttk.Checkbutton(content, text="Two", variable=twovar, onvalue=True)
three = ttk.Checkbutton(content, text="Three", variable=threevar, onvalue=True)
ok = ttk.Button(content, text="Okay")
cancel = ttk.Button(content, text="Cancel")

content.grid(column=0, row=0, sticky=(N, S, E, W))
frame.grid(column=0, row=0, columnspan=3, rowspan=2, sticky=(N, S, E, W))
namelbl.grid(column=3, row=0, columnspan=2, sticky=(N, W), padx=5)
name.grid(column=3, row=1, columnspan=2, sticky=(N,E,W), pady=5, padx=5)
one.grid(column=0, row=3)
two.grid(column=1, row=3)
three.grid(column=2, row=3)
ok.grid(column=3, row=3)
cancel.grid(column=4, row=3)

root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)
content.columnconfigure(0, weight=3)
content.columnconfigure(1, weight=3)
content.columnconfigure(2, weight=3)
content.columnconfigure(3, weight=1)
content.columnconfigure(4, weight=1)
content.rowconfigure(1, weight=1)

root.mainloop()