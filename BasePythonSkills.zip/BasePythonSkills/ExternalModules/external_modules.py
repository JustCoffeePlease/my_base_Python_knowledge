# Внешние модули это модули, написанные другими программистами
# и размещенные на серверах интернета.
# Неплохой сайт PyPI.org
# Для установки необходимо в командной строке cmd вбить pip instal 'название модуля'

import termcolor
print(termcolor.colored('Hello termcolor', 'green', 'on_red'))
help(termcolor)
