import csv


def add_student(first_name, last_name, age):
    with open('students_data.csv', 'a+', newline='') as file:
        csv_writer = csv.writer(file)
        csv_writer.writerow([first_name, last_name, age])

add_student('John', 'Black', '19')
add_student('Jenipher', 'Aniston', '32')
add_student('Piter', 'Parkes', '26')
