import csv

with open('students_data.csv') as file:
	csv_reader = csv.reader(file)
	for object in csv_reader:
		print(object)