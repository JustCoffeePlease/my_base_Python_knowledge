def get_access(password):
    password_list = [111, 222, 333, 444, 123, 234, 456]
    assert int(password) in password_list, 'Password is invalid'
    print('Welcome back')


pasword_1 = input('Please, input your password: ')
get_access(pasword_1)
