# car_prices = {'opel': 5000, 'toyota': 7000, 'BMW': 10000}
# print(car_prices)
# print(car_prices['toyota'])
#
# Adding
# car_prices['mazda'] = 4000
# print(car_prices)
#
# Changing
# car_prices['opel'] = 8000
# print(car_prices)
#
# Deleting
# del car_prices ['toyota']
# print(car_prices)
#
# Clearing
# car_prices.clear()
# print(car_prices)

person = {'first name': 'Jack',
          'last name': 'Brown',
          'age': 43,
          'hobbies': ['football', 'singing', 'photo'],
          'children': {'son': 'Michael', 'daughter': 'Pamela'}}

# print(person['age'])
# print(person['hobbies'])
hobbies = person['hobbies']
# print(hobbies[2])

# print(person['hobbies'][2])  # another variant

children = person['children']
# print(children['son'])

# print(person['children']['son']) # annother variant

# Adding new
person['car'] = 'Mazda'
# print(person)

#Changing
person['hobbies'][0] = 'hockey'
# print(person)

# printing dict keys, values, items
# print(person.keys())
# print(person.values())
# print(person.items())


# Hometask

computer = {'TYPE': 'laptop', 'NAME': 'Lenovo', 'DIAGONAL': 17, 'GRAPHIC CARDS': 'nvidia'}
computer['DIAGONAL'] = 16
print(computer['GRAPHIC CARDS'])
