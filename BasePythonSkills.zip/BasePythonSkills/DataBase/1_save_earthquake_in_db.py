import requests, sqlite3

#Create data base
conn = sqlite3.connect('1_earthquake_db.db')
cursor = conn.cursor()

# Crate table
cursor.execute("CREATE TABLE earthquake (count INTEGER, place TEXT, Magnitude TEXT);")


# Request formation
start_time = input('Enter the start time: ')
end_time = input('Enter the end time: ')
latitude = input('Enter the latitude: ')
longitude = input('Enter the longitude: ')
max_radius_km = input('Enter the max radius in km: ')
min_magnitude = input('Enter the min magnitude: ')

# Get response from https://earthquake.usgs.gov/fdsnws/event/1/query?
url = 'https://earthquake.usgs.gov/fdsnws/event/1/query?'

response = requests.get(url, headers={'Accept':'application/json'}, params={
		'format':'geojson',
		'starttime':start_time,
		'endtime':end_time,
		'latitude':latitude,
		'longitude':longitude,
		'maxradiuskm':max_radius_km,
		'minmagnitude':min_magnitude

})

# Insert new data in data base
insert_query = "INSERT INTO earthquake VALUES (?, ?, ?);"

data = response.json()

earthquake_list = data['features']
count = 0
for earthquake in earthquake_list:
	count += 1
	cursor.execute(insert_query, (count, earthquake['properties']['place'] , earthquake['properties']['mag']))


conn.commit()
conn.close()