# Generation expression

# Генератор создан при помощи функции генератора (с использованием yield)
def get_number_from_range():
    x = input('Enter the number for range ')
    for number in range(10):
        yield number


counter = get_number_from_range()
print(counter)
# print(next(counter))
# print(next(counter))
# print(next(counter))
# print(next(counter))
# print(next(counter))
# print(next(counter))
# print(next(counter))
# print(next(counter))
# print(next(counter))
# print(next(counter))
# print(next(counter))

# Генератор создан при помощи Generation expression
counter_1 = (number for number in range(10))
print(counter_1)
# print(next(counter_1))
# print(next(counter_1))
# print(next(counter_1))
# print(next(counter_1))
# print(next(counter_1))
# print(next(counter_1))
# print(next(counter_1))

# print([number for number in range(10)]) # Получаем список чисел, когда добавляем квадратные скобки

x = int(input('Enter any number for range: '))
counter_2 = (number**2 for number in range(x))
print(next(counter_2))
print(next(counter_2))
print(next(counter_2))
print(next(counter_2))
print(next(counter_2))

