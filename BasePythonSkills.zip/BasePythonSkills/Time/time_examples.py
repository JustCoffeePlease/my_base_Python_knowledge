import time

# print(time.gmtime(0))
# # Output:
# # time.struct_time(tm_year=1970, tm_mon=1, tm_mday=1, tm_hour=0, tm_min=0, tm_sec=0, tm_wday=3, tm_yday=1, tm_isdst=0)
# print(time.gmtime())
#
# print(time.localtime())
#
# print(time.time())

# epoch_start_time = time.gmtime(0)
# print(epoch_start_time)
# print('Year ', epoch_start_time[0])
# print('Month ', epoch_start_time[1])
# print('Day ', epoch_start_time[2])
#
# print('Year ', epoch_start_time.tm_year)
# print('Month ', epoch_start_time.tm_mon)
# print('Day ', epoch_start_time.tm_mday)
# print('Day of week ', epoch_start_time.tm_wday)



# print(time.ctime(time.time()))
# # Output:
# # Получаем локальное время
#
# print(time.ctime(9999999999))
# # Output:
# # Sat Nov 20 20:46:39 2286
#
# print("text before delay")
# time.sleep(5)
# print("text after 5 seconds")


local_time = time.localtime()
print(local_time)
print(time.mktime(local_time))
print(time.localtime(1638804574.0))
# Output:
# time.struct_time(tm_year=2021, tm_mon=12, tm_mday=6, tm_hour=18, tm_min=30, tm_sec=2,
#                                                                   tm_wday=0, tm_yday=340, tm_isdst=0)
# 1638804602.0
# time.struct_time(tm_year=2021, tm_mon=12, tm_mday=6, tm_hour=18, tm_min=29,
#                                                                   tm_sec=34, tm_wday=0, tm_yday=340, tm_isdst=0)

print(time.asctime(local_time))
# Output:
# Mon Dec  6 18:31:18 2021

print(time.strftime('%X', local_time))
# Output:
# 18:32:23

print(time.strftime('%x %X', local_time))
# Output:
# 12/06/21 18:32:55

print(time.strftime('%m/%d/%Y, %H:%M:%S', local_time))
# Output:
# 12/06/2021, 18:34:35

time_string = '06 December, 2021'
struct_time = time.strptime(time_string, '%d %B, %Y')
print(struct_time)
# Output:
# time.struct_time(tm_year=2021, tm_mon=12, tm_mday=6, tm_hour=0, tm_min=0, tm_sec=0,
#                                                                              tm_wday=0, tm_yday=340, tm_isdst=-1)
