import time

input('Press enter to start')

# start_time = time.time()
# for i in range(1, 1000000):
#     x = i * i
# end_time = time.time()
# print(x)
# print(end_time - start_time)

# Если мы измеряем время функцией time(), то при введении данных со стороны,
# например, когда администратор изменил время на компьютере, функция может
# работать некорректно.

# Можно для замера времени использовать функцию monotonic()
# start_time = time.monotonic()
# for i in range(1, 1000000):
#     x = i * i
# end_time = time.monotonic()
# print(x)
# print(end_time - start_time)

# так же можно использовать perf_counter() - recommended
start_time = time.perf_counter()
for i in range(1, 1000000):
    x = i * i
end_time = time.perf_counter()
print(x)
print(end_time - start_time)
