import random
import time

input('let\'s play a cool game? Press Enter to start')

start_time = time.perf_counter()

questions_answers = []
questions_answers.append(['Ближайшая к Солнцу планета – Марс?', 'F'])
questions_answers.append(['Археологи – это люди, которые должны проектировать здания?', 'F'])
questions_answers.append(['Правда, что в шахматной партии ферзь важнее королевы?', 'F'])
questions_answers.append(['Правда, что ножовкой можно пилить?', 'T'])
questions_answers.append(['Правда, что если смешать красный и зеленый, то получится коричневый?', 'T'])
questions_answers.append(['Верно ли утверждение, что изобретателями бумаги являются японцы?', 'F'])
questions_answers.append(['Верно ли утверждение, что запасов пресной воды на планете меньше, чем соленой?', 'T'])
questions_answers.append(['Правда, что, если божью коровку рассердить, она начинает больно кусаться?', 'F'])
questions_answers.append(['Верна ли примета, что когда куры в пыли купаются, то это к отличной погоде?', 'F'])
questions_answers.append(['Правда, что белые медведи во время охоты закрывают лапой нос, чтобы их не заметила жертва?', 'F'])

# Каждый раз вопросы будут выпадать в разном порядке
random.shuffle(questions_answers)

# Количество очков
user_score = 0

#
for item in questions_answers:
    print('True or false: ' + item[0])
    answer = input('Please enter T if true and F if False: ')
    if answer.capitalize() == item[1]:
        print('Excelent! ')
        user_score += 1
    else:
        print('You were wrong :-( Let\'s go next')

end_time = time.perf_counter()

result_time = end_time - start_time
print('You are total score is: ' + str(user_score))
print('Your time is ' + str(result_time))
