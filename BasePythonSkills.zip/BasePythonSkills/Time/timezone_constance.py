import time

print('UTC time: ' + time.strftime('%Y/%m/%d %H:%M:%S', time.gmtime()))
print('Local time: ' + time.strftime('%Y/%m/%d %H:%M:%S', time.localtime()))

# Output:
# UTC time: 2021/12/06 15:55:52
# Local time: 2021/12/06 18:55:52

print(time.altzone)
# Output:
# -14400
# Это сдвиг локальной DST timezone и оно со знаком '-', если оно находится восточнее
# UTS timezone

print(time.daylight)
# Output:
# 0

print(time.timezone)
# Output:
# -10800
# Это сдвиг локальной timezone в секундах от UTS timezone

print(time.timezone/60/60)

# print(time.tzname)
# Output:
# ('RTZ 2 (зима)', 'RTZ 2 (лето)')

if time.daylight != 0:
    print(time.tzname[1])

print(time.localtime().tm_zone)
print(time.localtime().tm_gmtoff)

# Output:
# RTZ 2 (зима)
# 10800
