import first

print('Top level in second.py')

first.function_1()

if __name__ == '__main__':
    print('first.py is being run directly')
else:
    print('first.py has been imported')

# Так ккак мы импортировали first, то у нас запускается этот файл и срабатывает команда print('Top level in second.py')
# Далее идет условный оператор if __name__ == '__main__'. Переменной __name__ не было присвоено значение '__main__',
# Именно поэтому выводится first.py has been imported.
# Далее, когда уже закончился код в модуле first.py запускается команда print('Top level in second.py'),
# далее запускается first.function_1(), которая выводит 'function_1() from first.py
# и далее, уже в second.py при проверке if __name__ == '__main__', так как мы его запустили непосредственно,
# в этом случае он не был импортирован, срабатывает первая ветка кода