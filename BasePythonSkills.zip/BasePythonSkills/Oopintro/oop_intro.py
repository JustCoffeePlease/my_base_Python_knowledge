# help(list)

class MyFirstClass:
    pass

object_of_my_class = MyFirstClass()
print(type(object_of_my_class))