# unittest - python module with unit testing framework
# unit testing - common conception of testing small pieces of your code
# Программа тестируется по кусочкам кода - это концепция unit testing