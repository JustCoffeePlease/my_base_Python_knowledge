def upper_text(text):
	return text.title()


	