# class Car:
#
#     wheels_number = 4
#
#     def __init__(self, name, color, year, is_crushed):
#         self.name = name
#         self.color = color
#         self.year = year
#         self.is_crushed = is_crushed

#
#
# mazda_car = Car(name = 'Mazda CX7', color = 'red', year = 2017, is_crushed = True)
# print(mazda_car.name)
# print(mazda_car.color)
# print(mazda_car.year)
# print(mazda_car.is_crushed)
# print(mazda_car.wheels_number)
#
# bmw_car = Car(name = 'BMW', color = 'black', year = 2018, is_crushed = False)
# print(bmw_car.name)
# print(bmw_car.color)
# print(bmw_car.year)
# print(bmw_car.is_crushed)
# print(bmw_car.wheels_number)
#
#
# number_of_wheels_of_three_cars =Car.wheels_number * 3
# print(number_of_wheels_of_three_cars)


# Hometask

class BlogPost:
    def __init__(self, user_name, text, number_of_likes):
        self.user_name = user_name
        self.text = text
        self.number_of_likes = number_of_likes


user_1 = BlogPost(user_name = 'Alex', text = 'I\'m an engineer', number_of_likes = 5)
user_2 = BlogPost(user_name = 'Olesia', text= 'I\'m a support expert', number_of_likes= 8)

print(user_1.user_name)
print(user_1.text)
print(user_1.number_of_likes)

user_2.number_of_likes = 1000

print(user_2.user_name)
print(user_2.text)
print(user_2.number_of_likes)

# class BlogPost:
#     def __init__(self, user_name, text, number_of_likes):
#         self.user_name = user_name
#         self.text = text
#         self.number_of_likes = number_of_likes
#
#
# post_about_politicians = BlogPost('John', 'I like politicians', 0)
# post_about_cats = BlogPost('Jane', 'I like cats', 0)
#
# post_about_cats.number_of_likes = 1000
#
# print(post_about_politicians.number_of_likes)
# print(post_about_cats.number_of_likes)