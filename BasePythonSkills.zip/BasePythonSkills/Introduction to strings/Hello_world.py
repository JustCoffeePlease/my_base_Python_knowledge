#print('Hello world')
#print("Hello python")
#print(123)
#print(2 + 2)
#print(3 - 2)
#print(2 * 2)
#print(8 / 2)
# print(3 // 2) #Оператор округляет деление в меньшую сторону
#print(2 ** 3) #Возведение в степень
# print(5 % 3) #Вычисление остатка от деления

#Homework 1

#print(3 * 7)
#print(4 ** 3)
#print(29 % 4)

X = 5
print(X)
X = 'Hello'
print(X)
type_of_variable = type(X)
print(type_of_variable)

#x = 18
#y = 5

# print(x + y)
# print(x - y)
# print(x * y)
# print(x ** y)
# print(x / y)
# print(x // y)
# print(x % y)


#Calculating of credit sum

credit = 6500000
credit_rate = 9
number_of_years = 20
final_sum = credit + credit / 100 * credit_rate * number_of_years
print(final_sum)




