greeting = 'Hello'
first_name = 'Jack'
last_name = 'White'
exclamation_sign = '!'

# print(greeting + ' ' + first_name + ' ' + last_name + exclamation_sign)
whole_sentence = greeting + ' ' + first_name + ' ' \
    + last_name + exclamation_sign
long_string = 'This is the long string'
print(long_string)

#Escaping \
some_string = "I'm a programmer"
print(some_string)
another_string = 'I wanna learn "Python"'
print(another_string)

some_string_1 = 'I\'m a programmer'
print(some_string_1)
another_string_1 = "I wanna learn \"Python\""
print(another_string_1)

# \n
string_with_new_line = 'Hello! \nMy name is Alex'
print(string_with_new_line)

# \r
string_with_new_line_1 = 'Hello! \n             \rI am a diver'
print(string_with_new_line_1)

# \t
numbers = '1\t23\t4567'
print(numbers)

some_text = "\tHello! \n\tI'm glad to see you"
print(some_text)

#Triple quotes
string_with_triple_quotes = """This is text with 
"triple quotes" """
print(string_with_triple_quotes)


#Hometask 1
name = 'Aleksei'
surname = 'Vasiliev'
print('Hi! my name is ' + surname + ' ' + name)

#Hometask 2

song_1 = '''
\t\tBaa, baa, black sheep
\t\tHave you any wool?
\t\tYes sir, yes sir,
\t\tThree bags full

\t\tOne for the master,
\t\tOne for the dame,
\t\tAnd one for the little boy
\t\tWho lives down the lane'''
print(song_1)


song_2 = '\n\t\tBaa, baa, black sheep,'\
       '\n\t\tHave you any wool?' \
       '\n\t\tYes sir, yes sir,' \
       '\n\t\tThree bags full' \
     '\n\n\t\tOne for the master,' \
       '\n\t\tOne for the dame,' \
       '\n\t\tAnd one for the little boy' \
       '\n\t\tWho lives down the lane' \
     '\n\n\t\tBaa, baa, black sheep' \
       '\n\t\tHave you any wool?' \
       '\n\t\tYes sir, yes sir,' \
       '\n\t\tThree bags full' \

print(song_2)