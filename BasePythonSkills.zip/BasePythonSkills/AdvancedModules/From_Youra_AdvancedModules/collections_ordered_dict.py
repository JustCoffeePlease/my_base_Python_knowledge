rainbow_colors_dict = {}
rainbow_colors_dict[1] = 'red'
rainbow_colors_dict[2] = 'orange'
rainbow_colors_dict[3] = 'yellow'
rainbow_colors_dict[4] = 'green'
rainbow_colors_dict[5] = 'blue'
rainbow_colors_dict[6] = 'indigo'
rainbow_colors_dict[7] = 'violet'

print(rainbow_colors_dict)
