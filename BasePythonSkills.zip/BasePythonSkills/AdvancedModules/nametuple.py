# jack = ('Jake', 'Smith', 19, 'male')
# jim = ('Jim', 'Blade', 23, 'male')
# jane = ('Jane', 'Morrison', 20, 'female')

# print(jack[0])
# print(jim[3])

# output:
# Jake
# male

from  collections import  namedtuple

Person = namedtuple("Person", "name surname age gender")

new_jack = Person(name='Jake', surname='Smith', age=19, gender='male')
new_jim = Person(name='Jim', surname='Blade', age=23,gender='male')
new_jane = Person(name='Jane', surname='Morrison', age=20, gender='female')

print(new_jack[0])
# output: Jake

print(new_jack.name)
# output: Jake

print(new_jane.age)
# output: 20

print(new_jane.surname)
# output: Morrison

new_jane = new_jane._replace(surname='Blade')

print(new_jane.surname)
# output: Blade