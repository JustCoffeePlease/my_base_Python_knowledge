
my_dict = {1: 'a'}

# print(my_dict[1])
# Output: a
# print((my_dict[2]))
# Output: KeyError: 2


from collections import defaultdict
# my_dict_2 = defaultdict(lambda: 1)
# my_dict_2[1] = 'a'
#
# print(my_dict_2[2])

s = 'Hello'
d = defaultdict(int)
for k in s:
    d[k] +=1
print(sorted(d.items()))
# Output: [('H', 1), ('e', 1), ('l', 2), ('o', 1)]
