# collections - Встроенный в Python модуль,который имплементирует специальные
# контейнерные типы данных, которые предоставляют альтернативы list, dict, set и tuple

from collections import Counter

number_list = [1, 3, 3, 4, 5, 5, 1, 3]
string = 'aabbcccdddddefghhh'
# print(Counter(number_list))
# print(Counter(string))

# Получаем словарь, в котором содержатся пары ключ-значение
# Ключи это сами элементы списка, а значения это количество этих элементов в списке
# Чем больше раз встречается элемент - тем раньше он выводится в Counter
# Output:
# Counter({3: 2, 5: 2, 1: 1, 4: 1})
# Counter({'d': 5, 'c': 3, 'h': 3, 'a': 2, 'b': 2, 'e': 1, 'f': 1, 'g': 1})


# Разделяя методом split строку, мы можем подсчитать, сколько раз встречаются элементы строки
sentence = 'Hello How are you doing? Hello, I\'m fine. How do you do? Hey Hey Hey'
# print(Counter(sentence.split(' ')))
# Output:
# Counter({'Hey': 3, 'How': 2, 'you': 2, 'Hello': 1, 'are': 1, 'doing?': 1, 'Hello,': 1, "I'm": 1, 'fine.': 1, 'do': 1, 'do?': 1})

# Common patterns

c = Counter(sentence.split(' '))
# print(sum(c.values()))
# Output: 15

# Сброс счетчика
# c.clear()
# Output: 0

# Преобразование в список
print(list(c))
# Output:
# ['Hello', 'How', 'are', 'you', 'doing?', 'Hello,', "I'm", 'fine.', 'do', 'do?', 'Hey']
print(set(c))
print(dict(c))
# Output: Преобразование в множетсво и в словарь

# c = c.items()
print(c)
# Output:
# dict_items([('Hello', 1), ('How', 2), ('are', 1), ('you', 2), ('doing?', 1), ('Hello,', 1), ("I'm", 1), ('fine.', 1),
# ('do', 1), ('do?', 1), ('Hey', 3)])

# c = Counter(dict(c))
print(c)
# Output:
# Counter({'Hey': 3, 'How': 2, 'you': 2, 'Hello': 1, 'are': 1, 'doing?': 1, 'Hello,': 1,
# "I'm": 1, 'fine.': 1, 'do': 1, 'do?': 1})

print((c.most_common()))
# Output:
#[('Hey', 3), ('How', 2), ('you', 2), ('Hello', 1), ('are', 1), ('doing?', 1), ('Hello,', 1), ("I'm", 1), ('fine.', 1), ('do', 1), ('do?', 1)]
print(c.most_common(2))
# [('Hey', 3), ('How', 2)]

print(c.most_common()[:-3-1:-1])
# Output: Три самых редко встречающихся элемента
# [('do?', 1), ('do', 1), ('fine.', 1)]


