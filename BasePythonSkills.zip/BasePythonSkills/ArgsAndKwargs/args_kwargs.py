# *args and **kwargs
# args - arguments, kwargs - key word args
# используется чтобы получать в качестве параметров функции произвольное количество параметров,
# чтобы не использовать большое количество переменных при определении функции

# # *args - при использовании получаем объект tuple
# def func_with_args(*args):
#     print(args)
#
# func_with_args(1, 2, 3)

# # Функция возвращает 10% от произведения
# def ten_percent_of_product(x, y):
#     return (x * y ) * 0.1
#
# print(ten_percent_of_product(10,20))
#
# def ten_percent_of_product_with_args(*args):
#     product = 1
#     for number in args:
#         product = product * number
#     return product * 0.1
#
#
# print(ten_percent_of_product_with_args(10, 20, 5))

# def percent_of_product_with_args(percent, *args):
#     # percent ставится в начале, так как при передаче действительного позиционного аргумента
#     # первое число будет расцениваться как позиционный параметр.
#     product = 1
#     for number in args:
#         product = product * number
#     return product / 100 * percent
# # Первое число является позиционным аргументом percent
# print(percent_of_product_with_args(10, 10, 20, 5))


# **kwargs - при использовании получаем объект dictionary
# def func_with_kwargs(**kwargs):
#     print(kwargs)
#
#
# func_with_kwargs(first=1, second=2, third=3)

# Ключ должен быть словом, как 'name'
# def hello_with_kwargs(**kwargs):
#     if 'name' in kwargs:
#         print('Hello! Nice to meet you, {}'.format(kwargs['name']))
#     else:
#         print('Hello! What is your name?')
#
# hello_with_kwargs(gender = 'male', age = 24, name = 'Jack')
# hello_with_kwargs(gender = 'male', age = 24)

# def hello_with_greeting_and_kwargs(greeting, **kwargs):
#     if 'name' in kwargs:
#         print('{}! Nice to meet you, {}'.format(greeting, kwargs['name']))
#     else:
#         print('{}! What is your name?'.format(greeting))
#
# hello_with_greeting_and_kwargs('Hola', gender = 'male', age = 24, name = 'Jack')
# hello_with_greeting_and_kwargs('Hello', gender = 'male', age = 24)


# *args и **kwargs в одной функции
# def func_with_args_and_kwargs(*args, **kwargs):
#     print('I wood like {} {}'.format(args[0], kwargs['food']))
#
# func_with_args_and_kwargs(1,'two', drink = 'coffee', food = 'sandwich')


# Hometask 1
#
# def is_cat_here(*args):
#     if 'cat' in str(list(args)).lower():
#         return True
#     else:
#         return False

# def is_cat_here_1(*args):
#     args_in_lower_case = [str(argument).lower() for argument in list(args)]
#     if 'cat' in args_in_lower_case:
#         return True
#     else:
#         return False

# print(is_cat_here('tiger','fish', 'cat'))
# print(is_cat_here_1('tiger','fish', 'cat'))

# Hometask 2

# def is_item_here(item, *args):
#     if item in args:
#         return True
#     else:
#         return False
#
# print(is_item_here(6, 56, 58, 5, 8))


# Hometask 3


def your_favourite_color(my_color, **kwargs):
    if 'color' in kwargs:
        print('My favourite color is ' + str(my_color) +
              ', but ' + kwargs['color'] + ' is also pretty good!')
    else:
        print('My favourite color is ' + str(my_color) +
              ', what is your favourite color?')


your_favourite_color('green', first_color = 'red', color = 'blue', third_color = 'brown')

