# x = 0
#
# if x > 3:
#     print('x > 3')
# elif x < 3:
#     print(' x < 3')
#     print('I\'m happy!')
# else:
#     print('x == 3')

# day_time = 'midnight'
#
# if day_time == 'morning':
#     print('Monster wakes up')
# elif day_time == 'afternoon':
#     print('Monster is walking')
# elif day_time == 'evening':
#     print('Monster is eating')
# elif day_time == 'night':
#     print('Monster is sleeping')
# else:
#     print('Monster is hunting')

# x = 45
#
# if x % 2 == 0:
#     print('x is even')
# else:
#     print('x is odd')
# print('Some text')

# user_input = input('Input something ')
# if user_input == 'Hello':
#     print('Hello! nice ti meet you')

# False: 0, empty string, None, empty object
#
# if None:
#     print('Hey')

# lucky_number = input('Please enter some number ')
#
# if lucky_number:
#     print(lucky_number + ' is your lucky number')
# else:
#     print('You have to enter some number, try again')

# Hometask_1

number = input('Enter any number ')

if int(number) == 7:
    print('7 is a lucky number! Today is your lucky day!')
else:
    print('Thank you! Have a nice day!')

# Hometask_2

int_number = input('Enter an integer number ')
if int(int_number) % 2 == 0:
    print('The ' + int_number + ' is even')
else:
    print('The ' + int_number + ' is odd')

print(type(int_number))