# Special (magic) methods __method_name__

# class Person:
#     def __init__(self, first_name, last_name, age):
#         self.first_name = first_name
#         self.last_name = last_name
#         self.age = age
#
#     def __str__(self):
#         return self.first_name + ' ' + self.last_name
#
#     def __len__(self):
#         return self.age
#
#     def __add__(self, other):
#         return self.age + other.age
#
#     def __del__(self): # Вызывается всегда, когда объект собирается удалять из памяти сборщик мусора
#         print('Person object with name ' + self.first_name + ' is deleted from memory')
#
#
# jack = Person('Jack', 'White', 45)
# # print([1, 2, 3, 4, 5, 6, 7, 8, 9])
# print(jack)
# print(len(jack))
# # del (jack)
# # print(jack)
# #
x = 5
# y = '5'
y = 3

a = '5'
b = '3'
# print(type(x), type(y))
# print(x, y)
# print(a + b)

print(x.__add__(y))
print(a.__add__(b))
# jane = Person('Jane', 'Eyre', 23)
# print(jack + jane)


# Hometask

# class Chain:
#     def __init__(self, number_of_items):
#         self.number_of_items = number_of_items
#
#     def __str__(self):
#         return 'Chain with ' + str(self.number_of_items) + ' items'
#
#     def __len__(self):
#         return self.number_of_items
#
# a = Chain(8)
# print(a.__str__())
# print(a.__len__())
