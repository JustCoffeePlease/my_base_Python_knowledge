# # Built-in functions
# x = print('Hello')
# y = set()
#
# print(type(x))
# print(type(y))
#
# print(x)
# print(y)
#
# # Built-in methods
# my_list = [1, 2, 3]
# my_list.append(4)
# print(my_list)
# my_list.clear()
# print(my_list)

# Create own functions

# def print_greeting():
#     '''
#     Print 'Hello' text
#     :return: None
#     '''
#     print('Hello')
#
# # Call to the function
# print(print_greeting())
#
# # Receive the description of the function
# help(print_greeting)

# def print_greeting_with_name(name = 'Name'):
#     '''
#     :param name
#     :return: None
#     '''
#     print('Hello ' + name + '!')
# print(print_greeting_with_name())
# help(print_greeting_with_name)
# print(print_greeting_with_name('Jane'))
# x = print(print_greeting_with_name('Jane'))
# print(x) # Функция ничего не возвращает

# def sum_of_two_numbers(a = 0, b = 0): # Во избежании вывода ошибки, необходимо задавать переменным исходные значения
#     '''
#
#     :param a: The first addend
#     :param b: The second addent
#     :return: Summ a and b
#     '''
#     return a + b # Для функций с возвращаемыми значениями необходимо указывать return
#
# x = sum_of_two_numbers(45, 7)
# print(x)
# help(sum_of_two_numbers)
# print(sum_of_two_numbers())

# def is_hello_in_text(text = 'Hello'):
#     if 'hello' in text.lower():
#         return True
#     else:
#         return False
# print(is_hello_in_text('Say Hello everyone'))

# Еще один вариант записи
# def is_hello_in_text(text):
#     return 'hello' in text.lower()
#
# print(is_hello_in_text('Say Hello everyone'))
#
# def is_string_in_text(string, text):
#     return string in text
# print(is_string_in_text('he', 'The apple'))
# print(is_string_in_text('k', 'The apple'))

# def greeting_depends_of_gender(name, gender):
#     if gender == 'male':
#         print('Hello ' + name + '! You looks great')
#         # Запись кода должа быть до return, потому что после return происходит выход из функции
#         return gender
#     elif gender == 'female':
#         print('Hello ' + name + '! You are so beautiful')
#         return gender
#     else:
#         print('Hello ' + name + '! What the fuck in your jeans?')
#         return gender
#
#
# returned_value_1 = greeting_depends_of_gender('Jack', 'male')
# returned_value_2 = greeting_depends_of_gender('Jane', 'female')
# returned_value_3 = greeting_depends_of_gender('Jack', 'shemale')
#
# print(returned_value_1)
# print(returned_value_2)
# print(returned_value_3)

# Hometask 1

def cat_voice():
    print('Meow!')


def dog_voice():
    print('Woof!')

print(cat_voice())
print(dog_voice())

# Hometask 2

def cat_voice():
    return ' Meow!'*2

def dog_voice():
    return ' Woof!'*2


x = cat_voice()
y = dog_voice()

print(x)
print(y)

# Hometask 3

def get_voice(voice = 'La la la'):
    return (voice + '!')
print(get_voice())

# Hometask 4.1

def odd_range(a = 0,b = 0):
    odd_list = []
    for x in range(a,b):
        if x % 2 == 1:
            odd_list.append(x)
    return odd_list

print(odd_range(2,10))

# Hometask 4.2

def odd_range_1(a = 0, b = 0):
    special_list = [num for num in range(a, b) if num % 2 == 1]
    return special_list


print(odd_range_1(2, 15))