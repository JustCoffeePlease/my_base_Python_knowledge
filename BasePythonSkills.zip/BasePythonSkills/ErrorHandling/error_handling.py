# SyntaxError
# des function_1():
#     x = 1 + 1
#     print(x)

# NameError
# print(x)

# TypeError
# len(1)
# my_list = [1, 2, 3]
# print(my_list + 'hello')

# IndexError
# my_list = [1, 2, 3]
# print(my_list[3])
# print('hello'[5])

# ValueError
# print(int('43'))
# print(int('he'))
# print(int([43]))

# KeyError
# my_dict = {'first': 'apple', 'second': 'orange'}
# # my_dict['third']
# my_dict['first']

# AttributeError
# 'red'.attr()

