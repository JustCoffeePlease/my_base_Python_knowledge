# Один из случаев использования декораторов - возможность ограничивать какие-либо аргументы функций
# Например, возможно сделать декоратор, который, при передаче определенного типа аргументов вызывает ошибку
# либо выходить за пределы фукций
# Создадим декоратор, который будет запрещать передавать аргументы kwargs
from functools import wraps

def prohibit_kwargs(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if kwargs:
            raise ValueError('Keyword arguments are prohibited')
        return func(*args, **kwargs)
    return wrapper

# Декоратор, запрещающий integer аргументы


def prohibit_int_arguments(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        for val in args:
            if type(val) == int:
                raise ValueError('Integer arguments are prohibited')
        for key, val in kwargs.items():
            if type(val) == int:
                raise ValueError('Integer arguments are prohibited')
        return func(*args, **kwargs)
    return wrapper

@prohibit_int_arguments
def print_hello(name):
    print(f'Hello {name}')


# print_hello('Jack')
# При активном декораторе @prohibit_kwargs, если ввести print_hello(name='Jack')
# То мы получим ValueError: Keyword arguments are prohibited
# print_hello(3)
# При активном декораторе prohibit_int_arguments, если ввести print_hello(3)
# То мы получим ValueError: Integer arguments are prohibited


# Hometask
# Создайте функцию-декоратор prohibit_more_than_2_args, которая выполняет функцию, которую она декорирует,
# если в этой функции не больше двух аргументов. В противном случае должна вызываться ошибка ValueError
# с сообщением "Function must have less than 3 arguments!"

def prohibit_more_than_2_args(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        args_list = []
        kwargs_list = []
        for value in args:
            args_list.append(value)
        for key_value in kwargs:
            kwargs_list.append(key_value)
        sum_args_and_kwargs = len(args_list) + len(kwargs_list)
        if sum_args_and_kwargs > 2:
            raise StopIteration('Function must have less than 3 arguments!')
        else:
            print(f'You have {sum_args_and_kwargs} arguments')
        return func(*args, **kwargs)
    return wrapper


@prohibit_more_than_2_args
def func_with_args_kwargs(*args, **kwargs):
    return args, kwargs


print(func_with_args_kwargs('52', 5, key='value'))
