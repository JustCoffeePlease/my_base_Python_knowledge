# class Car:
#
#     wheels_number = 4
#
#     def __init__(self, name, color, year, is_crushed):
#         self.name = name
#         self.color = color
#         self.year = year
#         self.is_crushed = is_crushed
#
#     def drive(self, city):
#         print(self.name + ' is driving to ' + city)
#
#     def change_color(self, new_color):
#         self.color = new_color
#
# # Ключевое отличие метода и атрибута в том, как мы к нему обращаемся
# # состоит в том, что после метода, как и при вызове функции, мы указываем ()
# # При обращении к атрибуту этих скобок нет. Это происходит потому, что метод это функция
# # Атрибут не выполняет никаких действий, это скорее переменная объекта, которая содержит какое-то значение
# opel_car = Car('Opel Astra', 'Grey', '2006', True)
# land_cruiser_car = Car('Land Cruiser', 'black', 2014, False )
# opel_car.drive('Berlin')
# land_cruiser_car.drive('Moscow')
# land_cruiser_car.change_color('grey')
# print(land_cruiser_car.color)



# class Circle:
#     pi = 3.1415
#     def __init__(self, radius = 1):
#         self.radius = radius
#         self.circumference = 2 * Circle.pi * self.radius
#
#     def get_area(self):
#         return self.pi * (self.radius**2)
#
#     # def get_circumference(self):
#     #     return 2 * self.pi * self.radius
#
#
# circle_1 = Circle()
# print(circle_1.get_area())
#
# circle_2 = Circle()
# circle_area = circle_2.get_area()
# # circle_circumference = circle_2.get_circumference()
# print(circle_area)
# print(circle_2.circumference)
# # print(circle_circumference)

# Hometask

# class BancAccount:
#
#     def __init__(self, client_id, client_first_name, client_last_name, balance = 0.0):
#         self.client_id = client_id
#         self.client_first_name = client_first_name
#         self.client_last_name = client_last_name
#         self.balance = balance
#
#     def add (self, add_balance):
#         self.balance = self.balance + add_balance
#
#     def withdraw (self, off_balance):
#         self.balance = self.balance - off_balance
#
#
# alex = BancAccount('aleva5', 'Vasilev', 'Aleksei', 30000 )
# print(alex.client_id)
# print(alex.client_first_name)
# print(alex.client_last_name)
# print(alex.balance)
#
# plus_money = input('Введите сумму пополнения: ')
# alex.add(int(plus_money))
# print(alex.balance)
#
# minus_money = input('Введите сумму списания: ')
# alex.withdraw(int(minus_money))
# print(alex.balance)


# Hometask from Youra

# class BankAccount:
#
#     def __init__(self, client_id, client_first_name,
#                  client_last_name):
#         self.client_id = client_id
#         self.client_first_name = client_first_name
#         self.client_last_name = client_last_name
#         self.balance = 0.0
#
#     def add(self, amount):
#         self.balance += amount
#
#     def withdraw(self, amount):
#         self.balance -= amount
#
#
# account_1 = BankAccount(1, 'John', 'Brown')
# account_2 = BankAccount(2, 'Jim', 'White')
#
#
# account_1.add(1000)
# print(account_1.balance)
# account_1.withdraw(500)
# print(account_1.balance)
# print(account_2.balance)

# Hometask from noname

# class BankAccount:
#     def __init__(self,client_id,client_first_name,client_last_name,balance=0.0):
#         self.client_id=client_id
#         self.client_first_name=client_first_name
#         self.client_last_name=client_last_name
#         self.balance=balance
#
#     def add(self,new_balance):
#         self.balance=self.balance+new_balance
#         return self.balance
#
#     def witdraw(self,cashout):
#         self.balance=self.balance-cashout
#         return self.balance
#
# alex = BankAccount('aleva5', 'Vasilev', 'Aleksei', 30000 )
# alex.add(10000)
# print(alex.balance)



##############################################################################################

class Gamer:

    active_gamers = 0

    @classmethod
    def get_active_gamers(cls):
        return Gamer.active_gamers

    @classmethod
    # def gamer_from_string(cls):
    #     john = cls('la Bomb', 25, 2, 34)
    #     print(john.get_age())
    def gamer_from_string(cls, data_string):
        nickname, age, level, points = data_string.split(',')
        return cls(nickname, age, level, points)

    def __init__(self, nickname, age, level, points):
        self.nickname = nickname
        self.age = age
        self.level = level
        self.points = points
        Gamer.active_gamers += 1

    def get_nickname(self):
        return self.nickname

    def get_age(self):
        return self.age

    def get_level(self):
        return self.level

    def get_point(self):
        return self.points

    def is_adult(self):
        return self.age >= 18

    def get_adult_level_permission(self):
        if self.is_adult():
            print('You can go to adult level')
        else:
            print('You can\'t go to adult level')

    def logout(self):
        Gamer.active_gamers -=1
#

# print(Gamer.active_gamers)
# gamer_1 = Gamer('Hellboy', 23, 5, 13)
# print(Gamer.active_gamers)
# gamer_2 = Gamer('Harry Potter', 13, 7, 34)
# print(Gamer.active_gamers)
#
# print(gamer_1.get_age())
# gamer_1.get_adult_level_permission()
#
# print(gamer_2.get_age())
# gamer_2.get_adult_level_permission()
#
# gamer_1.logout()
# print(Gamer.active_gamers)
#
# print(Gamer.get_active_gamers())


# Gamer.gamer_from_string()
# james = Gamer.gamer_from_string('James, 34, 2, 45')
# jane = Gamer.gamer_from_string('Jane, 24, 3, 5')
# print(james.get_age())
# print(jane.get_level())
# print(Gamer.active_gamers)

# my_dict = dict.fromkeys((1, 2, 3),('apple', 'orange', 'banana'))
# print(my_dict)