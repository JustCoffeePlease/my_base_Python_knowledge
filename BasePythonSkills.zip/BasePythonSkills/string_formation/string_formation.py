
# print(1 + 1)
# print('1' + '1')
# age = 23
# print('Jack is ' + str(age) + ' years old')


name = 'Jack'
age = 23
name_and_age = 'My name is {0}. I\'m {1} years old'.format(name, age)
# print(name_and_age)

name_and_age = 'My name is {0}. I\'m {1} years old'.format('Jack', 23)
# print(name_and_age)

name_and_age = 'My name is {}. I\'m {} years old'.format(23, 'Jack')
# print(name_and_age)

name = 'Jack'                                                   #New method
age = 23
name_and_age = f'My name is {name}. I\'m {age} years old'
# print(name_and_age)

print('My name is %s. I\'m %d years old' % (name, age))

week_days = 'There are 7 days in the week: {6}, {0}, {1}, {2}, {3}, {4}, {5}'\
    .format('\n Monday','\n Tuesday', '\n Wednesday', '\n Thursday', '\n Friday',
            '\n Saturday', '\n Sunday')
# print(week_days)

week_days = 'There are 7 days in the week: {su}, {su}, {su}, {mo}, {mo}, {mo}, {tu}' \
    .format(mo = '\n Monday', tu = '\n Tuesday', we = '\n Wednesday', th = '\nThursday', fr = '\n Friday',
           sa = '\n Saturday', su = '\n Sunday')
# print(week_days)

# float_result = 1000 / 7
# print(float_result)
# print('The result of division is {0:1.3f}'.format(float_result))
#
# print('''
#         {0:8.2f} {1:8.2f} {2:8.2f}
#         {3:8.2f} {4:8.2f} {5:8.2f}
#         {6:8.2f} {7:8.2f} {8:8.2f}'''.format(1.565656, 45.84552, 89.856,
#                            98.653274, 79.16161, 6.4915,
#     196.852, 78.5165, 456.9152))

# Hometask

homy = '''
{0:15.4f} {1:15.4f} {2:15.4f} {3:15.4f}
{4:15.4f} {5:15.4f} {6:15.4f} {7:15.4f}'''.format(2805.7897987, 2106.65161, 1210.741561, 9.511,
                          2803.96385, 31.0798421, 65.29842, 298.4191114 )

print(homy)

