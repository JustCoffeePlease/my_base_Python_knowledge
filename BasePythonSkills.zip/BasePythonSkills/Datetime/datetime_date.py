from datetime import date

# Возвращение текущей локальной даты
# today = date.today()
# print(today)
# Output:
# 2021-12-08

# print(today.year)
# print(today.month)
# print(today.day)

# date_1 = date(2021, 12, 8)
# date_2 = date(2020, 12, 8)
# diff = date_1 - date_2
# print(diff)
# # Output:
# # 365 days, 0:00:00
# print(type(date_1))
# print(type(date_2))
# print(type(diff))
# # Output:
# # <class 'datetime.date'>
# # <class 'datetime.date'>
# # <class 'datetime.timedelta'>

# Посчитаем количество дней до ДР

# today = date.today()
# birth = date(today.year, 6, 21)
# # Чтобы день рождения не указывался в текущем году, в случае, если он уже прошел
# # мы создаем условие, при котором, если ДР в этом году уже прошел, то будет указыватсья
# # дата в следующем году
# if birth < today:
#     birth = birth.replace(year=today.year + 1)
#     print(birth)
#
# # Получим значение, сколько дней осталось до дня рождения
# days_to_birth = birth - today
# print('Your birthday in ', days_to_birth)


# Определим какой сейчас день недели
# today = date.today()
#
# week_day = today.weekday()
# print(week_day) # Output: 2 - Нумерация начинается с нуля
# week_day = today.isoweekday()
# print(week_day) # Output: 3 - Нумерация начинается с 1

# Создадим приложение, которое будет запрашивать у пользователя данные:
# год, месяц, день. После этого будет определять какой это день недели

input('Hi there. To continue press ENTER')
year = input('Input year: ')
month = input('Input month: ')
day = input('Input day: ')

chosen_date = date(int(year), int(month), int(day))

if chosen_date.isoweekday() == 1:
    print('Monday')
elif chosen_date.isoweekday() == 2:
    print('Tuesday')
elif chosen_date.isoweekday() == 3:
    print('Wednesday')
elif chosen_date.isoweekday() == 4:
    print('Thursday')
elif chosen_date.isoweekday() == 5:
    print('Friday')
elif chosen_date.isoweekday() == 6:
    print('Saturday')
else:
    print('Sunday')


