# Рассмотрим best practices при использовании даты и времени
# Существуют Naive-объекты и aware-объекты.
# Их отличие в том, что naive не может себя расположить относительно других
# объектов во времени, то есть он не учитывает timezone и daylightsaving
# aware-объекты учитывают смещение timezone и daylightsaving.
# Все становится сложнее, когда приложение является интернациональным, то есть
# когда к нему имеют доступ пользователи со всего земного шара. Мало того, что
# в таком случае необходимо учесть все timezone, в некоторых странах есть
# daylightsaving, в некоторых его нет.
# Лучший способ чтобы не запутаться - использовать время в utc формате,
# проводить все манипуляции и далее, при выводе результата пользователю,
# необходимо перевести время из utc формата в какой-то локальный формат.

import datetime
import pytz

isoformat_string = '%Y-%m-%dT%H:%M:%S%z'

# strftime() приводит строку к форме записи, которую мы помещаем в ()
now_utc = datetime.datetime.now(pytz.timezone('UTC'))
print(now_utc.strftime(isoformat_string))
# Output:
# 2021-12-11T11:20:25+0000

# Создадим время в Москве
# в astimezone() передаем соответствующую timezone и дата/время интерпретируется
# уже к этой таймзоне
now_eu_msc = now_utc.astimezone(pytz.timezone('Europe/Moscow'))
print(now_eu_msc.strftime(isoformat_string))

# all_timezones = pytz.all_timezones
# for timezone in all_timezones:
#     print(timezone)

now_eu_istanbul = now_utc.astimezone(pytz.timezone('Europe/Istanbul'))
print(now_eu_istanbul.strftime(isoformat_string))


naive_now = datetime.datetime.now()
print(naive_now)
# Output: Получаем наивный объект без указания смещения timezone
# 2021-12-11 14:35:57.063805

# Мы можем получить из этого объекта aware объект
moscow_timezone = pytz.timezone('Europe/Moscow')
local_daytime = moscow_timezone.localize(naive_now)
print(local_daytime)
# Output: Получаем aware объект, знающий о смещении времени
# 2021-12-11 14:35:57.063805+03:00