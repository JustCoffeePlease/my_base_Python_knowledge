import pytz, datetime

# Просмотрим список ключей и значений, где ключ - сокращенное название страны RU
# for country in pytz.country_names:
#     print(country, pytz.country_names[country], pytz.country_timezones.get(country))

# Создадим функцию, которая будет вызываться, если пользователь захочет узнать коды всех стран
def all_countries():
    """
    This functiun will be calling if user want to know all short name of country
    :return: None
    """
    for country in pytz.country_names:
        print(country,pytz.country_names[country] )

# Создадим словарь, где ключ это короткое название страны, а значение это список,
# в который входит полное название страны и соответствующая timezone
country_with_timezone_dict = {}
for key, value in pytz.country_names.items():
     country_with_timezone_dict[key] = [value, pytz.country_timezones.get(key)]
# print(country_with_timezone_dict)


# Создадим функцию, которая будет проверять наличие страны в словаре country_with_timezone_dict
# и возвращать локальное время и время UTC. Если у страны несколько таймзон, пользователю необходимо
# выбрать интересующую
def time_in_country(country):
    """
    This function сhecks for the presence of a country in the list and prints the local time and UTC time
    If the country has several time zones, the user must select the appropriate one from the drop-down list

    :param country: must be an existing short country name
    :return: None
    """
    if country in pytz.country_names.keys():
        timezone = country_with_timezone_dict[country][1]
        if len(timezone) > 1:
            for object in timezone:
                print(object)
            city = input('Enter the one desired city from the list: ')
            tz_city = pytz.timezone(city)
            print('Local time is ', datetime.datetime.now(tz=tz_city))
            print('UTC time is ', datetime.datetime.utcnow())
        else:
            tz_timezone = pytz.timezone(timezone[0])
            print('Local time is ', datetime.datetime.now(tz=tz_timezone))
            print('UTC time is ', datetime.datetime.utcnow())
    else:
        print('Unknown name. Try again')

print('This app will let you know the local time in the selected country. '
      'Use its short name to select a country. For example: Russia is RU')
print("For a list of all countries press 'lst'")
print("Enter 'q' to exit the application")

input('\nPress any key to start')

while True:
    query = input('Please enter any query: ')
    if query == 'lst':
        all_countries()
    if query == 'q':
        break
    else:
        time_in_country(query)



