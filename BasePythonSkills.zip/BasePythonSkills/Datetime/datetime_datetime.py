from datetime import datetime

today = datetime(2021, 12, 11)
print(today)
# Output: Так как мф не передали время, мы получили вывод в таком формате: Указаны только год, месяц и число
# 2021-12-11 00:00:00

today_now = datetime.now()
print(today_now)
# Output:
# 2021-12-11 10:39:20.310224

# Метод timestamp() возвратит количество секунд с начала эпохи до текущего момента
timestamp = datetime.timestamp(today)
# print(timestamp)
# Output:
# 1639170000.0

timestamp_now = datetime.timestamp(today_now)
# print(timestamp_now)
# Output: Мы получаем уже большее количество секунд, так как учитываются часы и секунды
# 1639208504.088354

# Получим дату. Этот метод воссоздает дату из количества секунд с начала эпохи
today_from_timestamp = datetime.fromtimestamp(timestamp)
# print(today_from_timestamp)
# Output:
# 2021-12-11 00:00:00

# Используем строковое форматирование, то есть выводить дату в нужном нам формате
today_format = today.strftime('%d, %B, %Y')
# print('Today is ', today_format)
# Output:
# Today is  11, December, 2021

# Так же получим день недели при помощи форматирования
# print('Today is ', today.strftime('%A'))
# Output:
# Today is  Saturday

today2 = datetime.today()
# print(today2)
# Output:
# 2021-12-11 10:48:24.641117

# Переведем в utc формат
utc_format = today2.utcnow()
# print(utc_format)
# Output: Получаем сдвиг влево на три часа
# 2021-12-11 07:49:57.894570

# print(today2.date())
# print(today2.time())
# Output:
# 2021-12-11
# 10:51:17.562177

# print(today2.isocalendar())
# Output:
# datetime.IsoCalendarDate(year=2021, week=49, weekday=6)

# print(today2.isoformat())
#
#
