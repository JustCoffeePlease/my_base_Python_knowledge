import pytz
import datetime

print(datetime.datetime.today())
# Output:
# 2021-12-08 21:38:47.335510

print(datetime.datetime.now(None))
# Output:
# 2021-12-08 21:38:47.335509

print(datetime.datetime.utcnow())
# Output:
# 2021-12-08 18:38:47.335509

msc = 'Europe/Moscow' # Указываем таймзону
thai = 'Asia/Bangkok'

tz_msc = pytz.timezone(msc)
msc_time = datetime.datetime.now(tz=tz_msc)

tz_thai = pytz.timezone(thai)
thai_time = datetime.datetime.now(tz=tz_thai)

print(msc_time)
# Output:
# 2021-12-08 21:44:36.837629+03:00

print(thai_time)
# Output:
# 2021-12-09 02:00:04.078173+07:00

# Узнаем какие таймзоны существуют:
for tz in pytz.all_timezones:
    print(tz)

# Узнаем в каких странах какие часовые пояса
for country in pytz.country_names:
    print(country, pytz.country_names[country])

# Output:
# Получаем список ключей и значений, где ключ - сокращенное название страны RU
# а рядом полное название

    print(country, pytz.country_names[country], pytz.country_timezones.get(country))

# Output:
# список всех таймзон для каждой страны
