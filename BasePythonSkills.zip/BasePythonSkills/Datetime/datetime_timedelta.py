from datetime import timedelta, datetime

year = timedelta(days=365)
print(year)
# Output:
# 365 days, 0:00:00

today = datetime.now()
print('Today is ', today)
# Output:
# Today is  2021-12-11 11:04:09.754481

# Узнаем дату через 23 дня после текущей даты
print('23 days from will be ', (today + timedelta(days=23)))
# Output:
# 23 days from will be  2022-01-03 11:04:58.988985

# Мы можем передавать так же секунды и милисекнды
print('23000 seconds from will be ', (today + timedelta(seconds=23000)))
# Output:
# 23000 seconds from will be  2021-12-11 17:30:20.362412

# Узнаем сколько дней назад был ДР
last_birth = datetime(2021, 6, 21)
print('My last birthday was {0} days ago'.format((today-last_birth).days))
# Output:
# My last birthday was 173 days ago

# Узнаем сколько секунд в году
year = timedelta(days=365)
print('There are {0} seconds in a year'.format(year.total_seconds()))
# Output:
# There are 31536000.0 seconds in a year

# Узнаем сколько секунд в високосном году
leap_year = timedelta(days=366)
print('There are {0} seconds in a leap year'.format(leap_year.total_seconds()))
# Output:
# There are 31622400.0 seconds in a leap year

# Мы можем перемножать объекты, например вычислим сколько дней в семи годах
print('There ara {0} days in 7 years and {1} days in 7 leap years'
      .format((year * 7).days, (leap_year * 7).days))
# Output:
# There ara 2555 days in 7 years and 2562 days in 7 leap years
