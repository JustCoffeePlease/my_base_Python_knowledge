from time import time
from functools import wraps
from random import choice


def speed_test(function):
    @wraps(function) 
    def wrapper(*args, **kwargs):
        start_time = time()
        result = function(*args, **kwargs)
        end_time = time() - start_time
        print(f'The executing time is: {end_time}')
        return result
    return wrapper


@speed_test
def sum_numbers_from_range_list_comprehension(value):
    before_sum_list = [num for num in range(1, value)]
    result = sum(before_sum_list)
    return result


@speed_test
def sum_numbers_from_range_gen_expression(value_1):
    before_sum_list = (num for num in range(1, value_1))
    result = sum(before_sum_list)
    return result


# print(sum_numbers_from_range_list_comprehension(100000000))
# print(sum_numbers_from_range_gen_expression(100000000))

# Hometask
# Создайте функцию-декоратор hello_from_decorator,
# которая добавляет к возвращаемому значению функции,
# которую она декорирует, строку "Hello from decorator!"


def hello_from_decorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        func(*args, **kwargs)
        print('Hello from decorator')
        return func()
    return wrapper

@hello_from_decorator
def doing_something():
    colors_list = ['green', 'blue', 'red', 'black', 'violet', 'rose', 'brown', 'pearl']
    color = choice(colors_list)
    return color


print(doing_something())
