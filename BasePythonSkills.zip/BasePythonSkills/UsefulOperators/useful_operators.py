# for x in range(3,11,2):
#     print(x)
#
# print(range(5))
# print(list(range(5)))

# letter_index = 0
# my_string = 'abcdefg'
# for letter in my_string:
#     print(letter + ' is at index ' + str(letter_index))
#     letter_index = letter_index + 1

# # Функция enumerate
# my_string = 'abcdefg'
# for index, letter in enumerate(my_string): #Превращает my_string в tuple
#     print(letter + ' is at index ' + str(index))

# Функция in
# В строке
# print('a' in 'jack') # Есть ли буква 'a' в слове 'jack' ?
# print('x' in 'jack')
# print(str(1) in 'jack')

# В списке
# letter_list = ['a','b','c','d','e','f','g', True]
# print('a' in letter_list)
# print(1 in letter_list)
# print(True in letter_list)

# В словаре
# dict_1 = {1: 'a', 2: 'b', 3:'c', 4:'5'}
# print(1 in dict_1)
# print(5 in dict_1.keys())
# print('z' in dict_1.values())

# min, max
# print(min(1, 2, 3, 4))
# print(max(1, 2, 3, 4))
#
# my_lits = [1, 2, 3, 4]
# print(max(my_lits))
#
# print(max('Hello'))
# for letter in 'Hello':
#     print(ord(letter))


# Random
from random import shuffle
my_list = [1, 2, 3, 4]
shuffle(my_list)
print(my_list)

from random import randint
print(randint(1,10))