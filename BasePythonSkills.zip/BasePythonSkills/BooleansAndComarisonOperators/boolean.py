# print(1 < 2)
# print(type(True))

# Comparison operators
# print(1 == 1)
# print(1 == 2)
# print('Hello' == 'Hello')

# != не равно (1 не равно 1)
# print(1 != 1)
# print(1 != 2)
# print('Hello' == 'hello')

# print(1 > 2)
# print(1 < 2)
# print(2 >= 2)
# print(3 >= 2)
# print(2 <= 2)
# print(3 <= 2)
#
# print(ord('a'))
# print(ord('b'))
# print('a' > 'b')
# print('Hi' > 'Hello')
# print(ord('i'))
# print(ord('e'))

# x = 10
# y = 23
# print(x > y)
# print(x < y)
# print(x == y)
# print(x != y)

# age = int(input('Input your age: '))
# print('Access is permitted: ' + str(age >= 18))


print('Hometask_1')
x = input('Enter the first number: ')
y = input('Enter the second number: ')
print('first number = second number - ', x == y)
print('first number != second number - ', x != y)
print('first number > second number - ', x > y)
print('first number < second number - ', x < y)
print('first number =< second number - ', x <= y)
print('first number >= second number - ', x >= y)

print('Hometask_2')
letter = input('Enter any small letter: ')
big_letter = letter.upper()
print('The ACII-code of the ' + letter + ' is ' + str(ord(letter)) +
      '\nThe ACII-code of the capital ' + big_letter + ' is 5 ' + str(ord(big_letter)))
print(letter + ' == ' + big_letter + ' - ', letter == big_letter)
print(letter + ' != ' + big_letter + ' - ', letter != big_letter)
print(letter + ' > ' + big_letter + ' - ', letter > big_letter)
print(letter + ' < ' + big_letter + ' - ', letter < big_letter)
print(letter + ' <= ' + big_letter + ' - ', letter <= big_letter)
print(letter + ' => ' + big_letter + ' - ', letter > big_letter)