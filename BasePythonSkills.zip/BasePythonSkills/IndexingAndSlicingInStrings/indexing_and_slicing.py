
# Indexing
greeting = 'Helol Python!'
greeting_length = len(greeting)
# print(greeting_length)
# print(greeting[0])
# # print(greeting[-1])
#
# # Slicing
# print(greeting[2:5])
# print(greeting[6:10])
# print(greeting[-5:-2])
# print(greeting[2:])
# print(greeting[:5])
# print(greeting[:])
# print(greeting[::2])
# print(greeting[1::3])
print(greeting[1:9:3])

#Выстраивание элементов в обратном порядке
print(greeting[::-1])

# Hometask_1
print(greeting[3])
print('Hello Python'[3])

#  Hometask_2
print(greeting[:2])
print(greeting[-13:-11])

# Hometask_3
path = print(greeting[6] + 'a' + greeting[8:10])