with open ('test _binary', 'bw') as test_file: # bw означает запись кода в двоичной системе счисления
    # bytes преобразовывает числа в двоичный код, как int, str и т.д.
    # for number in range(21):
    #     test_file.write(bytes([number]))
# способ вывода числа в двоичном коде без цикла
    test_file.write(bytes(range(21)))


with open ('test _binary', 'br') as test_file:
    for number in test_file:
        print(number)