# Модуль pickle позволяет "консервировать" файл в двойчный код, а затем  извлекать его и восстанавливать все
# его данные в первоначальном виде

# Создание файла с двоичной системой счисления
import pickle
#
# honda = (
#     'civic',
#     'grey',
#     '2019',
#     (
#         (1, 'Jack Brown', ),
#         (2, 'Jane White'),
#         (3, 'Jake Green')
#     )
# )

# with open('honda.pickle', 'wb') as honda_file:
#     pickle.dump(honda, honda_file)

# Извлечение данных из файла с двоичной системой счисления

# with open('honda.pickle', 'rb') as honda_retrieved:
#     honda_from_file = pickle.load(honda_retrieved)
#
# print(honda_from_file)
#
# model, color, year, owner_list = honda_from_file
# print(model)
# print(color)
# print(year)
# for owner in owner_list:
#     owner_number, owner_name = owner
#     print((owner_number, owner_name))




###############################################
honda = (
    'civic',
    'grey',
    '2009',
    (
        (1, 'James Brown'),
        (2, 'Jane White'),
        (3, 'Jake Green')
    )
)

models = ['civic', 'accord', 'pilot']
owners = ['James Brown', 'Jane White', 'Jake Green']

with open('honda.pickle', 'wb') as honda_file:
    pickle.dump(honda, honda_file)
    pickle.dump(models, honda_file)
    pickle.dump(owners, honda_file)
    pickle.dump(9999999999, honda_file)

with open('honda.pickle', 'rb') as honda_retrieved:
    honda_from_file = pickle.load(honda_retrieved)
    models = pickle.load(honda_retrieved)
    owners = pickle.load(honda_retrieved)
    a = pickle.load(honda_retrieved)


print(honda_from_file)
print(models)
print(owners)
print(a)



########################################################

# data = {
#     'a': [1, 2, 3, 4, 5],
#     'b': ('character string', b'byte string'),
#     'c': (None, True, False)
# }
#
#
# with open('data_pickle', 'wb') as f:
#     pickle.dump(data, f) # Записывает сериализованный объект в файл
#
# with open('data_pickle', 'rb') as f:
#     new_data = pickle.load(f) # Загружает объект из файла
#     for item in new_data.items():
#         print(item)

