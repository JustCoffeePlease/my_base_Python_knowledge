import shelve
university = shelve.open('university_file')


university['shedules'] = {
        'monday_schedule': ['Math', 'English language', 'System programming', 'Python'],
        'tuesday_schedule': ['English language', 'HTML', 'Python', 'Football'],
        'wednesday_schedule': ['Physics', 'English language', 'Python'],
        'thursday_schedule': ['Math', 'Chemistry', 'Java'],
        'friday_schedule': ['Running', 'Math', 'Python']}
university['tutors'] = {
        'math': ['Jack White', 'Jim Black'],
        'python': ['Natasha Romanov', 'Jane Smith']}

print(university['shedules']['wednesday_schedule'])
print(university['tutors']['math'])
university.close()

# university = {
#     'shedules': {
#         'monday_schedule': ['Math', 'English language', 'System programming', 'Python'],
#         'tuesday_schedule': ['English language', 'HTML', 'Python', 'Football'],
#         'wednesday_schedule': ['Physics', 'English language', 'Python'],
#         'thursday_schedule': ['Math', 'Chemistry', 'Java'],
#         'friday_schedule': ['Running', 'Math', 'Python']
#     },
#     'tutors':{
#         'math': ['Jack White', 'Jim Black'],
#         'python': ['Natasha Romanov', 'Jane Smith']
#     }
# }
#
# print(university['shedules']['wednesday_schedule'])
# print(university['tutors']['math'])
