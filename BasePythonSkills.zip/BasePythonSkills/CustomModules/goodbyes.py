def say_goodbye():
    print('Good bye!')

def say_bye_bye():
    print('Bye-Bye!')

def say_hasta_la_vista():
    print('Hasta_la_vista!')