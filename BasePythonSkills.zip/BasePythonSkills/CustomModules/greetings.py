def say_hello():
    print('Hello!')

def say_hi():
    print('Hi!')

def say_hey_there():
    print('Hey there!')