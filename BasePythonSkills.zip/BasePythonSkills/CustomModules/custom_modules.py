# import greetings
#
# greetings.say_hello()

from greetings import say_hey_there
say_hey_there()


from goodbyes import say_goodbye as my_goodbye
my_goodbye()