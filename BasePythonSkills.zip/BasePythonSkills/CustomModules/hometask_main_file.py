def get_favourite_color():
    return 'super-duper color'

def get_favourite_number():
    return 13

