from hometask_main_file import get_favourite_color, get_favourite_number
x = get_favourite_color()
y = get_favourite_number()
print(x, y)