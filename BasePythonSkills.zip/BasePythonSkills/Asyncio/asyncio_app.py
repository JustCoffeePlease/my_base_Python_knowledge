import asyncio

# async def count(counter):
#     """
#     Принимаем в функцию счетчик и печатаем сколько у нас в нем записей
#     counter для примера будет списком. Таким образом мы определяем, сколько записей будет в этом списке
#     """
#     print(f'Количество записей в списке: {len(counter)}')
#
#     while True:
#         # Логика: не выполняй меня 1/1000 секунды, передай на этот период времени управление другим задачам.
#         # Это сделано в связи с тем, что следующая операция append выполняется слишком быстро.
#         await asyncio.sleep(1/1000)
#         counter.append(1)
#
#
# async def print_every_one_sec(counter):
#     while True:
#         await asyncio.sleep(1)
#         print(f'- 1 секунда прошла. Количество записей в спике: {len(counter)}')
#
#
# async def print_every_five_sec():
#     while True:
#         await asyncio.sleep(5)
#         print(f'----- 5 секунд прошлo.')
#
#
# async def print_every_ten_sec():
#     while True:
#         await asyncio.sleep(10)
#         print(f'---------- 10 секунд прошлo.')
#
#
# # Чтобы функции запускать конкурентно (ТИПО паралелльно), нужен специальный планировщик.
# # Этим планироващиком будет функция main.
# # Для этого есть два способа:
# # 1) Можно под каждую функцию заложить переменную, получаем карутины. Чтобы из карутин сделать задачи,
# #       мы их должны запланировать (функция create_task). Чтобы все задачи успевали выполнится и не блокировали друг друга,
# #       в конце всех create-task поставим блокирующую функцию await, которая будет выполняться.
# # 2) Все карутины разместисть в список, потом передать их в функцию gather и раскрыть их (поставить звездочку в начале)
# #       функцию gather нужно выполнить с помощью await. Таким образом, при запуске функции main, наша asyncio.gather(*tasks)
# # будет блокировать выполнение карутины main, пока не дождется ответа результата выполнения всех функций.
# async def main():
#     counter = list()
#
#     # c = count(counter)
#     # p1 = print_every_one_sec(counter)
#     # p5 = print_every_five_sec()
#     # p10 = print_every_ten_sec()
#     #
#     # asyncio.create_task(c)
#     # asyncio.create_task(p1)
#     # asyncio.create_task(p5)
#     # await p10
#
#     # Второй вариант записи
#
#     tasks = [count(counter),
#              print_every_one_sec(counter),
#              print_every_five_sec(),
#              print_every_ten_sec()]
#
#     await asyncio.gather(*tasks)
#
# asyncio.run(main())


"""***************************"""
import asyncio
from contextvars import ContextVar

MyCounter = ContextVar('counter', default=0)


async def increase():
    my_counter = MyCounter.get()

    my_counter += 1

    MyCounter.set(my_counter)


async def count():
    while True:
        await increase()
        my_counter = MyCounter.get()
        print(f'Счетчик: {my_counter}')

        await asyncio.sleep(1)

asyncio.run(count())


asyncio.run(main())