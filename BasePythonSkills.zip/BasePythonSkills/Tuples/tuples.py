tuple_1 = (1, 2, 3)
tuple_2 = ('one', 'hello')
tuple_3 = (3, 2.3, 'three')


# incorrect
# tuple_1[1] = 3

# correct
new_tuple = (tuple_1[0], 3, tuple_1[-1])
# print(new_tuple)

# print(tuple_1[1])
# print(type(tuple_1))
# print(tuple_2)
# print(tuple_3)

x = y = z = 12
# print(x,y,z)
x, y, z = 12, 13, 14
print(x, y, z)

person_tuple = ('John', 'Smith', 1986)
first_name, last_name, year_of_birth = person_tuple
print(first_name, last_name, year_of_birth)

t1 = (1, 2, 5, 1, 7, 9)
print(t1.count(1))

greetings_tuple = ('hi','hello', 'hey', 'hi')
print(greetings_tuple.count('hola'))

print(t1.index(5))
print(greetings_tuple.index('hi'))

# Hometask
computer_tuple = ('laptop','lenovo', 19, 'nvidia')
pc_type, pc_name, pc_diagonal, pc_video_card = computer_tuple
print('My pc properties: ', '\n', pc_type,'\n', pc_name,'\n', pc_diagonal,'\n', pc_video_card)




