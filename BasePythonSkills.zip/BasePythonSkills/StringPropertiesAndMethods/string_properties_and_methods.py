# Immutable
first_name = 'Jake'
print(first_name[2])
# first_name[2] = 'n'
# print(first_name)

first_two_words = first_name[:2]
last_letter = first_name[-1]

# Concatenable
new_name = first_two_words + 'n' + last_letter
print(new_name)

greeting = 'Hello'
greeting = greeting + ' Python'
print(greeting)

# Multiplication
yummy = 'Yum '
print(yummy * 2)

print(yummy.upper())
print(yummy.lower())

long_string = 'This is the long string'
# print(long_string.split())
print(long_string.split('s'))

# Hometask_1
home_greeting = 'Hello Python'
new_word = home_greeting[-6] + 'a' + home_greeting[-4:-2]
print(new_word)

# Hometask_2
z = 'z'
print(z * 7)
print((z * 7).upper())