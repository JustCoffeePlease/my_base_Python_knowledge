# # 1ый способ
smile = '\U0001f600'
quantity = 10
# Outer loop
for i in range(1, quantity + 1):
    # inner loop
    for j in range (1, i + 1):
        print(smile, end='')
    print('')
# Внешний цикл это количество печатаемых строк
# Так как количество (quantity) строк 10, то цикл будет выполнятся 10 раз
# Внутренний цикл - количество столбцов в каждой строке
# Для каждой итерации внешнего цикла количество столбцов увеличивается на 1
# В первой итерации внешнего цикла счетчик столбцов равен 1, в следующей - 2 и так далее
# Итерация внутреннего цикла равна количеству столбцов
# На каждой итерации внутреннего цикла мы печатаем smile

# 2й способ
for number in range(10):
    count = 0
    emoticans = ''
    while count <= number:
        emoticans += smile
        count += 1
    print(emoticans)

# Еще один способ
for num in range(1,11):
    print(smile * num)

# Или
count = 1
while count <= 11:
    print(smile * count)
    count += 1
